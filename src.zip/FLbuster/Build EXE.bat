@echo off
chcp 65001 > nul
title FLbuster - Сборка EXE
color 0B

echo.
echo ╔═══════════════════════════════════════════════════════════════╗
echo ║              FLBUSTER - СБОРКА EXE ФАЙЛА                      ║
echo ╚═══════════════════════════════════════════════════════════════╝
echo.

:: Check Python
echo [1/5] Проверка Python...
where python >nul 2>&1
if %errorLevel% neq 0 (
    echo [ОШИБКА] Python не найден!
    pause
    exit /b 1
)
python --version
echo [✓] Python найден
echo.

:: Install PyInstaller
echo [2/5] Установка PyInstaller...
python -m pip install pyinstaller --quiet
if %errorLevel% neq 0 (
    echo [ОШИБКА] Не удалось установить PyInstaller
    pause
    exit /b 1
)
echo [✓] PyInstaller установлен
echo.

:: Install dependencies
echo [3/5] Установка зависимостей...
python -m pip install -r requirements.txt --quiet
if %errorLevel% neq 0 (
    echo [ОШИБКА] Не удалось установить зависимости
    pause
    exit /b 1
)
echo [✓] Зависимости установлены
echo.

:: Build EXE
echo [4/5] Сборка EXE файла...
echo Это может занять несколько минут...
echo.

:: Convert icon if needed
set "ICON_PARAM="
if exist "Icon\icon.png" (
    echo Конвертация иконки из PNG в ICO...
    python convert_icon.py
    if exist "Icon\icon.ico" (
        set "ICON_PARAM=--icon=Icon\icon.ico"
        echo [✓] Используется иконка: Icon\icon.ico
    ) else (
        echo [!] Не удалось конвертировать иконку
    )
) else if exist "Icon\icon.ico" (
    set "ICON_PARAM=--icon=Icon\icon.ico"
    echo [✓] Используется иконка: Icon\icon.ico
) else if exist "flbuster_icon.ico" (
    set "ICON_PARAM=--icon=flbuster_icon.ico"
    echo [✓] Используется иконка: flbuster_icon.ico
) else if exist "zapret_icon.ico" (
    set "ICON_PARAM=--icon=zapret_icon.ico"
    echo [✓] Используется иконка: zapret_icon.ico
) else (
    echo [!] Иконка не найдена, сборка без иконки
)
echo.

python -m PyInstaller ^
    --name="FLbuster" ^
    --onefile ^
    --windowed ^
    %ICON_PARAM% ^
    --hidden-import=customtkinter ^
    --hidden-import=PIL ^
    --hidden-import=PIL._tkinter_finder ^
    --collect-all=customtkinter ^
    FLbuster.py

if %errorLevel% neq 0 (
    echo.
    echo [ОШИБКА] Не удалось собрать EXE
    echo.
    echo Попробуйте без иконки:
    echo python -m PyInstaller --name="FLbuster" --onefile --windowed FLbuster.py
    echo.
    pause
    exit /b 1
)

echo.
echo [✓] EXE файл собран
echo.

:: Move EXE
echo [5/5] Перемещение файла...
if exist "dist\FLbuster.exe" (
    move "dist\FLbuster.exe" "FLbuster.exe" >nul 2>&1
    echo [✓] FLbuster.exe готов!
) else (
    echo [!] Файл не найден в dist\
)
echo.

:: Cleanup
echo Очистка временных файлов...
if exist "build" rmdir /S /Q "build" >nul 2>&1
if exist "dist" rmdir /S /Q "dist" >nul 2>&1
if exist "FLbuster.spec" del /F /Q "FLbuster.spec" >nul 2>&1
echo [✓] Очистка завершена
echo.

echo ═══════════════════════════════════════════════════════════════
echo.
echo [УСПЕХ] FLbuster.exe создан!
echo.
echo Файл: FLbuster.exe
echo Размер: ~50-80 MB (включает Python и все библиотеки)
echo.
echo ВАЖНО: Структура для работы EXE:
echo.
echo   FLbuster/
echo   ├── FLbuster.exe          ← Запускайте этот файл
echo   └── appfiles/             ← Обязательно нужна эта папка!
echo       ├── general*.bat      ← Стратегии обхода
echo       ├── service.bat        ← Управление службами
echo       ├── bin/               ← winws.exe и другие
echo       ├── lists/             ← Списки доменов и IP
echo       └── utils/             ← Утилиты
echo.
echo Теперь вы можете:
echo   1. Запустить FLbuster.exe напрямую
echo   2. Создать ярлык на рабочем столе
echo   3. Скопировать FLbuster.exe + appfiles/ на другой ПК
echo.
echo ═══════════════════════════════════════════════════════════════
echo.
pause
