#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FLbuster - Modern graphical interface for DPI bypass
"""

import os
import sys
import subprocess
import threading
import json
from pathlib import Path
import customtkinter as ctk
from tkinter import messagebox, scrolledtext
import webbrowser

# Set appearance
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# Language translations
TRANSLATIONS = {
    "RU": {
        "title": "FLbuster - Панель управления обходом DPI",
        "logo": "🚀 FLbuster",
        "subtitle": "Обход DPI",
        "dashboard": "🏠 Главная",
        "service": "⚙️ Службы",
        "domains": "🌐 Домены",
        "settings": "🎮 Настройки",
        "updates": "🔄 Обновления",
        "tools": "🛠️ Инструменты",
        "about": "ℹ️ О программе",
        "appearance": "Тема:",
        "language": "Язык:",
        "dark": "Темная",
        "light": "Светлая",
        "system": "Системная",
        "blur_effect": "Эффект размытия:",
        "blur_enabled": "Включен",
        "blur_disabled": "Выключен",
        
        # Dashboard
        "dashboard_title": "Главная",
        "service_status": "Статус службы",
        "bypass_status": "Статус обхода",
        "checking": "Проверка...",
        "running": "✅ Запущена",
        "not_running": "❌ Не запущена",
        "active": "✅ Активен",
        "inactive": "❌ Неактивен",
        "quick_actions": "Быстрые действия",
        "install_service": "📥 Установить службу",
        "check_status": "🔍 Проверить статус",
        "run_diagnostics": "🩺 Запустить диагностику",
        "information": "Информация",
        "info_text": "FLbuster - инструмент обхода DPI для Discord, YouTube и других сервисов.\n\nБыстрый старт:\n1. Включите Secure DNS в браузере или Windows 11\n2. Установите службу через вкладку Службы\n3. Попробуйте разные стратегии, если одна не работает\n\nОснован на Zapret от bol-van. Подробнее в README.md.",
        
        # Service
        "service_title": "Управление службами",
        "install_service_section": "Установка службы",
        "select_strategy": "Выберите стратегию:",
        "install_selected": "📥 Установить выбранную стратегию",
        "service_control": "Управление службами",
        "remove_services": "🗑️ Удалить службы",
        "no_strategies": "Стратегии не найдены",
        
        # Settings
        "settings_title": "Настройки",
        "game_filter": "🎮 Игровой фильтр",
        "game_filter_desc": "Включить обход для игр и сервисов, использующих UDP/TCP на высоких портах",
        "ipset_filter": "🌐 IPSet фильтр",
        "ipset_filter_desc": "Управление фильтрацией IP из ipset-all.txt",
        "auto_update": "🔄 Автопроверка обновлений",
        "disabled": "Выключено",
        "tcp_udp": "TCP и UDP",
        "tcp_only": "Только TCP",
        "udp_only": "Только UDP",
        "none": "Нет",
        "loaded": "Загружено",
        "any": "Все",
        "enable_auto_update": "Включить автоматическую проверку обновлений",
        
        # Updates
        "updates_title": "Обновления",
        "update_ipset": "📋 Обновить список IPSet",
        "update_hosts": "📝 Обновить файл Hosts",
        "check_updates": "🔍 Проверить обновления",
        "update_info": "ℹ️ Информация об обновлениях",
        "update_info_text": "Список IPSet: Обновляет список IP-адресов для обхода\n\nФайл Hosts: Обновляет hosts для веб-версии Telegram и голосового чата Discord\n\nПроверка обновлений: Проверяет наличие новой версии FLbuster",
        
        # Tools
        "tools_title": "Инструменты",
        "console_output": "Вывод консоли",
        "run_tests": "🧪 Запустить тесты",
        "auto_select": "🎯 АвтоПодбор",
        "auto_select_title": "АвтоПодбор стратегии",
        "auto_select_text": "АвтоПодбор автоматически протестирует все доступные стратегии.\n\nКаждая стратегия будет проверена на работу с Discord и YouTube.\nТестирование займёт несколько минут.\n\nПродолжить?",
        "auto_select_running": "Тестирование стратегии",
        "auto_select_testing": "Проверка доступности сайтов...",
        "auto_select_found": "Стратегия найдена!",
        "auto_select_found_text": "Рабочая стратегия: {0}\n\nРезультаты тестов:\n{1}\n\nУстановить её как службу?",
        "auto_select_complete": "Тестирование завершено",
        "auto_select_complete_text": "Все стратегии протестированы.\n\nЛучшая стратегия: {0}\nРезультаты: {1}\n\nУстановить её как службу?",
        "auto_select_no_working": "Рабочая стратегия не найдена",
        "auto_select_no_working_text": "Ни одна стратегия не прошла тесты.\n\nПопробуйте:\n1. Включить Secure DNS\n2. Перезагрузить компьютер\n3. Проверить антивирус\n4. Запустить от администратора",
        
        # Domains
        "domains_title": "Управление доменами",
        "add_domain": "Добавить домен",
        "domain_placeholder": "example.com",
        "domain_list": "Список доменов",
        "add_button": "➕ Добавить",
        "remove_button": "🗑️ Удалить",
        "domain_example": "Пример: discord.com, youtube.com, twitch.tv",
        "domain_info": "ℹ️ Информация о доменах",
        "domain_info_text": "Добавьте домены, которые нужно обходить.\n\nФормат:\n- discord.com (точное совпадение)\n- *.discord.com (все поддомены)\n- *discord* (содержит discord)\n\nДомены сохраняются в appfiles/lists/list-general.txt\n\nПосле изменения перезапустите службу!",
        "domain_added": "Домен добавлен",
        "domain_removed": "Домен удален",
        "domain_exists": "Домен уже существует",
        "domain_empty": "Введите домен",
        "domain_invalid": "Неверный формат домена",
        
        # About
        "about_title": "О программе",
        "copyright": "Авторские права",
        "license": "Лицензия",
        "instructions": "Инструкции",
        "quick_start": "Быстрый старт",
        "contact": "Контакты",
        
        # Messages
        "admin_required": "Требуются права администратора",
        "admin_required_text": "FLbuster требует права администратора для управления службами.\n\nНекоторые функции могут не работать без прав администратора.\n\nПродолжить?",
        "install_confirm": "Установить службу",
        "install_confirm_text": "Установить '{0}' как службу Windows?\n\nЭто запустит обход автоматически при старте системы.",
        "remove_confirm": "Удалить службы",
        "remove_confirm_text": "Удалить все службы FLbuster?\n\nЭто остановит и удалит службу обхода.",
        "success": "Успешно",
        "error": "Ошибка",
        "services_removed": "Службы успешно удалены",
        "failed_remove": "Не удалось удалить службы",
        "status_updated": "Статус обновлен. Проверьте главную страницу.",
        "game_filter_updated": "Игровой фильтр обновлен. Перезапустите службу FLbuster для применения изменений.",
        "ipset_filter_updated": "IPSet фильтр успешно обновлен.",
        "update_ipset_confirm": "Обновить IPSet",
        "update_ipset_text": "Загрузить последний список IPSet из репозитория?",
        "ipset_updated": "Список IPSet успешно обновлен",
        "update_hosts_title": "Обновить Hosts",
        "update_hosts_text": "Обновление файла hosts требует ручных действий.\n\nИспользуйте appfiles/service.bat -> 'Update Hosts File' для этой операции.",
        "latest_version": "Установлена последняя версия: {0}",
        "new_version": "Доступна новая версия: {0}\nТекущая версия: {1}\n\nОткрыть страницу загрузки?",
        "update_available": "Доступно обновление",
        "run_tests_title": "Запустить тесты",
        "run_tests_text": "Тесты будут запущены в отдельном окне PowerShell.\n\nПроверьте окно PowerShell для просмотра результатов.",
        "test_script_not_found": "Скрипт тестирования не найден",
        "no_strategy": "Стратегия не выбрана",
        "installing_service": "Установка службы...",
        "service_installed": "Служба успешно установлена!",
        "service_install_failed": "Не удалось установить службу",
    },
    "EN": {
        "title": "FLbuster - DPI Bypass Control Panel",
        "logo": "🚀 FLbuster",
        "subtitle": "DPI Bypass Tool",
        "dashboard": "🏠 Dashboard",
        "service": "⚙️ Service",
        "domains": "🌐 Domains",
        "settings": "🎮 Settings",
        "updates": "🔄 Updates",
        "tools": "🛠️ Tools",
        "about": "ℹ️ About",
        "appearance": "Appearance:",
        "language": "Language:",
        "dark": "Dark",
        "light": "Light",
        "system": "System",
        "blur_effect": "Blur Effect:",
        "blur_enabled": "Enabled",
        "blur_disabled": "Disabled",
        
        # Dashboard
        "dashboard_title": "Dashboard",
        "service_status": "Service Status",
        "bypass_status": "Bypass Status",
        "checking": "Checking...",
        "running": "✅ Running",
        "not_running": "❌ Not Running",
        "active": "✅ Active",
        "inactive": "❌ Inactive",
        "quick_actions": "Quick Actions",
        "install_service": "📥 Install Service",
        "check_status": "🔍 Check Status",
        "run_diagnostics": "🩺 Run Diagnostics",
        "information": "Information",
        "info_text": "FLbuster - DPI bypass tool for Discord, YouTube and other services.\n\nQuick Start:\n1. Enable Secure DNS in your browser or Windows 11 settings\n2. Install a service using the Service tab\n3. Test different strategies if one doesn't work\n\nBased on Zapret by bol-van. For more information, check the README.md file.",
        
        # Service
        "service_title": "Service Management",
        "install_service_section": "Install Service",
        "select_strategy": "Select Strategy:",
        "install_selected": "📥 Install Selected Strategy",
        "service_control": "Service Control",
        "remove_services": "🗑️ Remove Services",
        "no_strategies": "No strategies found",
        
        # Settings
        "settings_title": "Settings",
        "game_filter": "🎮 Game Filter",
        "game_filter_desc": "Enable bypass for games and services using UDP/TCP on high ports",
        "ipset_filter": "🌐 IPSet Filter",
        "ipset_filter_desc": "Control which IPs are filtered from ipset-all.txt",
        "auto_update": "🔄 Auto-Update Check",
        "disabled": "Disabled",
        "tcp_udp": "TCP and UDP",
        "tcp_only": "TCP only",
        "udp_only": "UDP only",
        "none": "None",
        "loaded": "Loaded",
        "any": "Any",
        "enable_auto_update": "Enable automatic update checks",
        
        # Updates
        "updates_title": "Updates",
        "update_ipset": "📋 Update IPSet List",
        "update_hosts": "📝 Update Hosts File",
        "check_updates": "🔍 Check for Updates",
        "update_info": "ℹ️ Update Information",
        "update_info_text": "IPSet List: Updates the list of IP addresses to bypass\n\nHosts File: Updates hosts file for Telegram web and Discord voice chat\n\nCheck for Updates: Checks if a new version of FLbuster is available",
        
        # Tools
        "tools_title": "Tools",
        "console_output": "Console Output",
        "run_tests": "🧪 Run Tests",
        "auto_select": "🎯 Auto-Select",
        "auto_select_title": "Auto-Select Strategy",
        "auto_select_text": "Auto-Select will automatically test all available strategies.\n\nEach strategy will be tested for Discord and YouTube access.\nTesting will take several minutes.\n\nContinue?",
        "auto_select_running": "Testing Strategy",
        "auto_select_testing": "Checking site availability...",
        "auto_select_found": "Strategy Found!",
        "auto_select_found_text": "Working strategy: {0}\n\nTest results:\n{1}\n\nInstall it as a service?",
        "auto_select_complete": "Testing Complete",
        "auto_select_complete_text": "All strategies tested.\n\nBest strategy: {0}\nResults: {1}\n\nInstall it as a service?",
        "auto_select_no_working": "No Working Strategy Found",
        "auto_select_no_working_text": "No strategy passed the tests.\n\nTry:\n1. Enable Secure DNS\n2. Restart computer\n3. Check antivirus\n4. Run as administrator",
        
        # Domains
        "domains_title": "Domain Management",
        "add_domain": "Add Domain",
        "domain_placeholder": "example.com",
        "domain_list": "Domain List",
        "add_button": "➕ Add",
        "remove_button": "🗑️ Remove",
        "domain_example": "Example: discord.com, youtube.com, twitch.tv",
        "domain_info": "ℹ️ Domain Information",
        "domain_info_text": "Add domains that need to be bypassed.\n\nFormat:\n- discord.com (exact match)\n- *.discord.com (all subdomains)\n- *discord* (contains discord)\n\nDomains are saved to appfiles/lists/list-general.txt\n\nRestart service after changes!",
        "domain_added": "Domain added",
        "domain_removed": "Domain removed",
        "domain_exists": "Domain already exists",
        "domain_empty": "Enter domain",
        "domain_invalid": "Invalid domain format",
        
        # About
        "about_title": "About",
        "copyright": "Copyright",
        "license": "License",
        "instructions": "Instructions",
        "quick_start": "Quick Start",
        "contact": "Contact",
        
        # Messages
        "admin_required": "Administrator Rights Required",
        "admin_required_text": "FLbuster requires administrator rights to manage services.\n\nSome features may not work without admin rights.\n\nContinue anyway?",
        "install_confirm": "Install Service",
        "install_confirm_text": "Install '{0}' as a Windows service?\n\nThis will run the bypass automatically on system startup.",
        "remove_confirm": "Remove Services",
        "remove_confirm_text": "Remove all FLbuster services?\n\nThis will stop and uninstall the bypass service.",
        "success": "Success",
        "error": "Error",
        "services_removed": "Services removed successfully",
        "failed_remove": "Failed to remove services",
        "status_updated": "Status updated. Check the Dashboard for details.",
        "game_filter_updated": "Game filter updated. Restart FLbuster service to apply changes.",
        "ipset_filter_updated": "IPSet filter updated successfully.",
        "update_ipset_confirm": "Update IPSet",
        "update_ipset_text": "Download the latest IPSet list from repository?",
        "ipset_updated": "IPSet list updated successfully",
        "update_hosts_title": "Update Hosts",
        "update_hosts_text": "Hosts file update requires manual steps.\n\nPlease use appfiles/service.bat -> 'Update Hosts File' for this operation.",
        "latest_version": "You have the latest version: {0}",
        "new_version": "New version available: {0}\nCurrent version: {1}\n\nOpen download page?",
        "update_available": "Update Available",
        "run_tests_title": "Run Tests",
        "run_tests_text": "Tests will be launched in a separate PowerShell window.\n\nPlease check the PowerShell window for results.",
        "test_script_not_found": "Test script not found",
        "no_strategy": "No strategy selected",
        "installing_service": "Installing service...",
        "service_installed": "Service installed successfully!",
        "service_install_failed": "Failed to install service",
    }
}

class ZapretGUI(ctk.CTk):
    def __init__(self):
        super().__init__()
        
        # Set default language
        self.current_language = "RU"
        
        self.title(self.t("title"))
        self.geometry("900x650")
        self.minsize(800, 600)
        
        # Try to set icon if available
        try:
            # Check for icon in Icon folder first
            icon_path = Path(__file__).parent / "Icon" / "icon.ico"
            if not icon_path.exists():
                # Try PNG and convert to ICO
                png_path = Path(__file__).parent / "Icon" / "icon.png"
                if png_path.exists():
                    try:
                        from PIL import Image
                        img = Image.open(png_path)
                        icon_path = Path(__file__).parent / "Icon" / "icon.ico"
                        img.save(icon_path, format='ICO', sizes=[(256, 256), (128, 128), (64, 64), (32, 32), (16, 16)])
                    except:
                        icon_path = None
            
            # Fallback to old locations
            if not icon_path or not icon_path.exists():
                icon_path = Path(__file__).parent / "flbuster_icon.ico"
            if not icon_path.exists():
                icon_path = Path(__file__).parent / "zapret_icon.ico"
            
            if icon_path and icon_path.exists():
                self.iconbitmap(str(icon_path))
        except:
            pass
        
        # Get script directory (works for both .py and .exe)
        if getattr(sys, 'frozen', False):
            # Running as compiled executable
            self.script_dir = Path(sys.executable).parent.absolute()
        else:
            # Running as script
            self.script_dir = Path(__file__).parent.absolute()
        
        self.appfiles_dir = self.script_dir / "appfiles"
        
        # Configure grid
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        
        # Create sidebar
        self.create_sidebar()
        
        # Create main content area
        self.create_main_content()
        
        # Load initial status
        self.update_status()
    
    def t(self, key):
        """Get translation for current language"""
        return TRANSLATIONS.get(self.current_language, TRANSLATIONS["RU"]).get(key, key)
    
    def change_language(self, lang_code):
        """Change application language"""
        self.current_language = lang_code
        self.refresh_ui()
    
    def refresh_ui(self):
        """Refresh UI with new language"""
        # Update window title
        self.title(self.t("title"))
        
        # Recreate sidebar
        self.sidebar.destroy()
        self.create_sidebar()
        
        # Recreate main content
        for page in self.pages.values():
            page.destroy()
        self.pages.clear()
        
        self.create_dashboard_page()
        self.create_service_page()
        self.create_domains_page()
        self.create_settings_page()
        self.create_updates_page()
        self.create_tools_page()
        self.create_about_page()
        
        # Show current page
        self.show_page("dashboard")
        
        # Update status
        self.update_status()
        
    def create_sidebar(self):
        """Create sidebar with navigation"""
        self.sidebar = ctk.CTkFrame(self, width=200, corner_radius=0)
        self.sidebar.grid(row=0, column=0, sticky="nsew", padx=0, pady=0)
        self.sidebar.grid_rowconfigure(10, weight=1)
        
        # Logo/Title
        self.logo_label = ctk.CTkLabel(
            self.sidebar, 
            text=self.t("logo"), 
            font=ctk.CTkFont(size=24, weight="bold")
        )
        self.logo_label.grid(row=0, column=0, padx=20, pady=(20, 10))
        
        self.version_label = ctk.CTkLabel(
            self.sidebar, 
            text=self.t("subtitle"), 
            font=ctk.CTkFont(size=12)
        )
        self.version_label.grid(row=1, column=0, padx=20, pady=(0, 20))
        
        # Navigation buttons
        self.nav_buttons = {}
        nav_items = [
            (self.t("dashboard"), "dashboard"),
            (self.t("service"), "service"),
            (self.t("domains"), "domains"),
            (self.t("settings"), "settings"),
            (self.t("updates"), "updates"),
            (self.t("tools"), "tools"),
            (self.t("about"), "about"),
        ]
        
        for idx, (text, key) in enumerate(nav_items, start=2):
            btn = ctk.CTkButton(
                self.sidebar,
                text=text,
                command=lambda k=key: self.show_page(k),
                fg_color="transparent",
                text_color=("gray10", "gray90"),
                hover_color=("gray70", "gray30"),
                anchor="w",
                font=ctk.CTkFont(size=14)
            )
            btn.grid(row=idx, column=0, padx=20, pady=5, sticky="ew")
            self.nav_buttons[key] = btn
        
        # Language selector
        self.language_label = ctk.CTkLabel(
            self.sidebar, 
            text=self.t("language"), 
            anchor="w"
        )
        self.language_label.grid(row=18, column=0, padx=20, pady=(20, 0))
        
        self.language_menu = ctk.CTkOptionMenu(
            self.sidebar,
            values=["RU", "EN"],
            command=self.change_language,
        )
        self.language_menu.grid(row=19, column=0, padx=20, pady=(5, 10))
        self.language_menu.set(self.current_language)
        
        # Appearance mode
        self.appearance_label = ctk.CTkLabel(
            self.sidebar, 
            text=self.t("appearance"), 
            anchor="w"
        )
        self.appearance_label.grid(row=20, column=0, padx=20, pady=(10, 0))
        
        appearance_values = [self.t("dark"), self.t("light"), self.t("system")]
        self.appearance_menu = ctk.CTkOptionMenu(
            self.sidebar,
            values=appearance_values,
            command=self.change_appearance,
        )
        self.appearance_menu.grid(row=21, column=0, padx=20, pady=(5, 10))
        self.appearance_menu.set(self.t("dark"))
        
        # Blur effect
        self.blur_label = ctk.CTkLabel(
            self.sidebar, 
            text=self.t("blur_effect"), 
            anchor="w"
        )
        self.blur_label.grid(row=22, column=0, padx=20, pady=(10, 0))
        
        self.blur_var = ctk.BooleanVar(value=False)
        self.blur_switch = ctk.CTkSwitch(
            self.sidebar,
            text=self.t("blur_enabled"),
            variable=self.blur_var,
            command=self.toggle_blur,
            onvalue=True,
            offvalue=False
        )
        self.blur_switch.grid(row=23, column=0, padx=20, pady=(5, 20))
        
    def create_main_content(self):
        """Create main content area"""
        self.main_frame = ctk.CTkFrame(self, corner_radius=0)
        self.main_frame.grid(row=0, column=1, sticky="nsew", padx=0, pady=0)
        self.main_frame.grid_columnconfigure(0, weight=1)
        self.main_frame.grid_rowconfigure(0, weight=1)
        
        # Create pages
        self.pages = {}
        self.create_dashboard_page()
        self.create_service_page()
        self.create_domains_page()
        self.create_settings_page()
        self.create_updates_page()
        self.create_tools_page()
        self.create_about_page()
        
        # Show dashboard by default
        self.show_page("dashboard")
        
    def create_dashboard_page(self):
        """Create dashboard page"""
        page = ctk.CTkFrame(self.main_frame)
        page.grid_columnconfigure(0, weight=1)
        
        # Title
        title = ctk.CTkLabel(
            page, 
            text=self.t("dashboard_title"), 
            font=ctk.CTkFont(size=28, weight="bold")
        )
        title.grid(row=0, column=0, padx=30, pady=(30, 20), sticky="w")
        
        # Status cards
        status_frame = ctk.CTkFrame(page)
        status_frame.grid(row=1, column=0, padx=30, pady=10, sticky="ew")
        status_frame.grid_columnconfigure((0, 1), weight=1)
        
        # Service status card
        self.service_status_card = self.create_status_card(
            status_frame, 
            self.t("service_status"), 
            self.t("checking"),
            0, 0
        )
        
        # Bypass status card
        self.bypass_status_card = self.create_status_card(
            status_frame, 
            self.t("bypass_status"), 
            self.t("checking"),
            0, 1
        )
        
        # Quick actions
        actions_label = ctk.CTkLabel(
            page, 
            text=self.t("quick_actions"), 
            font=ctk.CTkFont(size=20, weight="bold")
        )
        actions_label.grid(row=2, column=0, padx=30, pady=(20, 10), sticky="w")
        
        actions_frame = ctk.CTkFrame(page)
        actions_frame.grid(row=3, column=0, padx=30, pady=10, sticky="ew")
        actions_frame.grid_columnconfigure((0, 1, 2), weight=1)
        
        # Action buttons
        btn_install = ctk.CTkButton(
            actions_frame,
            text=self.t("install_service"),
            command=lambda: self.show_page("service"),
            height=40,
            font=ctk.CTkFont(size=14)
        )
        btn_install.grid(row=0, column=0, padx=10, pady=10, sticky="ew")
        
        btn_check = ctk.CTkButton(
            actions_frame,
            text=self.t("check_status"),
            command=self.check_status,
            height=40,
            font=ctk.CTkFont(size=14)
        )
        btn_check.grid(row=0, column=1, padx=10, pady=10, sticky="ew")
        
        btn_diagnostics = ctk.CTkButton(
            actions_frame,
            text=self.t("run_diagnostics"),
            command=self.run_diagnostics,
            height=40,
            font=ctk.CTkFont(size=14)
        )
        btn_diagnostics.grid(row=0, column=2, padx=10, pady=10, sticky="ew")
        
        # Info section
        info_label = ctk.CTkLabel(
            page, 
            text=self.t("information"), 
            font=ctk.CTkFont(size=20, weight="bold")
        )
        info_label.grid(row=4, column=0, padx=30, pady=(20, 10), sticky="w")
        
        info_text = ctk.CTkTextbox(page, height=150)
        info_text.grid(row=5, column=0, padx=30, pady=10, sticky="ew")
        info_text.insert("1.0", self.t("info_text"))
        info_text.configure(state="disabled")
        
        self.pages["dashboard"] = page

    def create_service_page(self):
        """Create service management page"""
        page = ctk.CTkScrollableFrame(self.main_frame)
        page.grid_columnconfigure(0, weight=1)
        
        # Title
        title = ctk.CTkLabel(
            page, 
            text=self.t("service_title"), 
            font=ctk.CTkFont(size=28, weight="bold")
        )
        title.grid(row=0, column=0, padx=30, pady=(30, 20), sticky="w")
        
        # Install service section
        install_frame = ctk.CTkFrame(page)
        install_frame.grid(row=1, column=0, padx=30, pady=10, sticky="ew")
        install_frame.grid_columnconfigure(0, weight=1)
        
        install_label = ctk.CTkLabel(
            install_frame,
            text=self.t("install_service_section"),
            font=ctk.CTkFont(size=18, weight="bold")
        )
        install_label.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="w")
        
        # Strategy selection
        strategy_label = ctk.CTkLabel(
            install_frame,
            text=self.t("select_strategy"),
            font=ctk.CTkFont(size=14)
        )
        strategy_label.grid(row=1, column=0, padx=20, pady=(10, 5), sticky="w")
        
        # Get available strategies
        strategies = self.get_available_strategies()
        
        self.strategy_var = ctk.StringVar(value=strategies[0] if strategies else "general.bat")
        self.strategy_menu = ctk.CTkOptionMenu(
            install_frame,
            variable=self.strategy_var,
            values=strategies if strategies else ["No strategies found"],
            width=400
        )
        self.strategy_menu.grid(row=2, column=0, padx=20, pady=5, sticky="w")
        
        # Button frame for install and test
        button_frame = ctk.CTkFrame(install_frame, fg_color="transparent")
        button_frame.grid(row=3, column=0, padx=20, pady=20, sticky="ew")
        button_frame.grid_columnconfigure((0, 1), weight=1)
        
        install_btn = ctk.CTkButton(
            button_frame,
            text="📥 Install Selected Strategy",
            command=self.install_service,
            height=40,
            font=ctk.CTkFont(size=14)
        )
        install_btn.grid(row=0, column=0, padx=(0, 10), sticky="ew")
        
        test_btn = ctk.CTkButton(
            button_frame,
            text="🧪 Start Strategy",
            command=self.test_strategy,
            height=40,
            font=ctk.CTkFont(size=14),
            fg_color="#2196F3",
            hover_color="#1976D2"
        )
        test_btn.grid(row=0, column=1, padx=(10, 0), sticky="ew")
        
        # Service control section
        control_frame = ctk.CTkFrame(page)
        control_frame.grid(row=2, column=0, padx=30, pady=10, sticky="ew")
        control_frame.grid_columnconfigure((0, 1), weight=1)
        
        control_label = ctk.CTkLabel(
            control_frame,
            text=self.t("service_control"),
            font=ctk.CTkFont(size=18, weight="bold")
        )
        control_label.grid(row=0, column=0, columnspan=2, padx=20, pady=(20, 10), sticky="w")
        
        remove_btn = ctk.CTkButton(
            control_frame,
            text="🗑️ Remove Services",
            command=self.remove_services,
            height=40,
            fg_color="#d32f2f",
            hover_color="#b71c1c"
        )
        remove_btn.grid(row=1, column=0, padx=20, pady=20, sticky="ew")
        
        status_btn = ctk.CTkButton(
            control_frame,
            text="📊 Check Status",
            command=self.check_status,
            height=40
        )
        status_btn.grid(row=1, column=1, padx=20, pady=20, sticky="ew")
        
        self.pages["service"] = page
    
    def create_domains_page(self):
        """Create domains management page"""
        page = ctk.CTkScrollableFrame(self.main_frame)
        page.grid_columnconfigure(0, weight=1)
        
        # Title
        title = ctk.CTkLabel(
            page, 
            text=self.t("domains_title"), 
            font=ctk.CTkFont(size=28, weight="bold")
        )
        title.grid(row=0, column=0, padx=30, pady=(30, 20), sticky="w")
        
        # Add domain section
        add_frame = ctk.CTkFrame(page)
        add_frame.grid(row=1, column=0, padx=30, pady=10, sticky="ew")
        add_frame.grid_columnconfigure(0, weight=1)
        
        add_label = ctk.CTkLabel(
            add_frame,
            text=self.t("add_domain"),
            font=ctk.CTkFont(size=18, weight="bold")
        )
        add_label.grid(row=0, column=0, columnspan=2, padx=20, pady=(20, 10), sticky="w")
        
        # Example text
        example_label = ctk.CTkLabel(
            add_frame,
            text=self.t("domain_example"),
            font=ctk.CTkFont(size=12),
            text_color="gray"
        )
        example_label.grid(row=1, column=0, columnspan=2, padx=20, pady=(0, 10), sticky="w")
        
        # Input frame
        input_frame = ctk.CTkFrame(add_frame, fg_color="transparent")
        input_frame.grid(row=2, column=0, columnspan=2, padx=20, pady=(0, 20), sticky="ew")
        input_frame.grid_columnconfigure(0, weight=1)
        
        # Domain entry
        self.domain_entry = ctk.CTkEntry(
            input_frame,
            placeholder_text=self.t("domain_placeholder"),
            height=40,
            font=ctk.CTkFont(size=14)
        )
        self.domain_entry.grid(row=0, column=0, padx=(0, 10), sticky="ew")
        
        # Add button
        add_btn = ctk.CTkButton(
            input_frame,
            text=self.t("add_button"),
            command=self.add_domain,
            height=40,
            width=120,
            font=ctk.CTkFont(size=14)
        )
        add_btn.grid(row=0, column=1, sticky="e")
        
        # Domain list section
        list_frame = ctk.CTkFrame(page)
        list_frame.grid(row=2, column=0, padx=30, pady=10, sticky="nsew")
        list_frame.grid_columnconfigure(0, weight=1)
        list_frame.grid_rowconfigure(1, weight=1)
        
        list_label = ctk.CTkLabel(
            list_frame,
            text=self.t("domain_list"),
            font=ctk.CTkFont(size=18, weight="bold")
        )
        list_label.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="w")
        
        # Domains listbox
        self.domains_textbox = ctk.CTkTextbox(list_frame, height=250, font=ctk.CTkFont(size=13))
        self.domains_textbox.grid(row=1, column=0, padx=20, pady=(0, 10), sticky="nsew")
        
        # Buttons frame
        buttons_frame = ctk.CTkFrame(list_frame, fg_color="transparent")
        buttons_frame.grid(row=2, column=0, padx=20, pady=(0, 20), sticky="ew")
        
        refresh_btn = ctk.CTkButton(
            buttons_frame,
            text="🔄 " + self.t("check_status"),
            command=self.load_domains,
            height=40,
            width=150
        )
        refresh_btn.pack(side="left", padx=(0, 10))
        
        remove_btn = ctk.CTkButton(
            buttons_frame,
            text=self.t("remove_button"),
            command=self.remove_domain,
            height=40,
            width=150,
            fg_color="#d32f2f",
            hover_color="#b71c1c"
        )
        remove_btn.pack(side="left")
        
        # Info section
        info_frame = ctk.CTkFrame(page)
        info_frame.grid(row=3, column=0, padx=30, pady=10, sticky="ew")
        info_frame.grid_columnconfigure(0, weight=1)
        
        info_label = ctk.CTkLabel(
            info_frame,
            text=self.t("domain_info"),
            font=ctk.CTkFont(size=18, weight="bold")
        )
        info_label.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="w")
        
        info_text = ctk.CTkTextbox(info_frame, height=150)
        info_text.grid(row=1, column=0, padx=20, pady=(0, 20), sticky="ew")
        info_text.insert("1.0", self.t("domain_info_text"))
        info_text.configure(state="disabled")
        
        self.pages["domains"] = page
        
        # Load domains initially
        self.load_domains()
    
    def load_domains(self):
        """Load domains from list-general.txt"""
        try:
            list_file = self.appfiles_dir / "lists" / "list-general.txt"
            if not list_file.exists():
                list_file = self.script_dir / "lists" / "list-general.txt"
            
            if list_file.exists():
                with open(list_file, 'r', encoding='utf-8', errors='ignore') as f:
                    domains = f.read()
                
                self.domains_textbox.configure(state="normal")
                self.domains_textbox.delete("1.0", "end")
                self.domains_textbox.insert("1.0", domains)
                self.domains_textbox.configure(state="disabled")
            else:
                self.domains_textbox.configure(state="normal")
                self.domains_textbox.delete("1.0", "end")
                self.domains_textbox.insert("1.0", "Файл list-general.txt не найден")
                self.domains_textbox.configure(state="disabled")
        except Exception as e:
            messagebox.showerror(self.t("error"), f"Ошибка загрузки доменов:\n{str(e)}")
    
    def add_domain(self):
        """Add domain to list-general.txt"""
        domain = self.domain_entry.get().strip()
        
        if not domain:
            messagebox.showwarning(self.t("error"), self.t("domain_empty"))
            return
        
        # Basic validation
        if ' ' in domain:
            messagebox.showwarning(self.t("error"), self.t("domain_invalid"))
            return
        
        try:
            list_file = self.appfiles_dir / "lists" / "list-general.txt"
            if not list_file.exists():
                list_file = self.script_dir / "lists" / "list-general.txt"
            
            # Check if domain already exists
            if list_file.exists():
                with open(list_file, 'r', encoding='utf-8', errors='ignore') as f:
                    existing_domains = f.read()
                
                if domain in existing_domains.split('\n'):
                    messagebox.showinfo(self.t("error"), self.t("domain_exists"))
                    return
            
            # Add domain
            with open(list_file, 'a', encoding='utf-8') as f:
                f.write(f"\n{domain}")
            
            messagebox.showinfo(self.t("success"), f"{self.t('domain_added')}: {domain}")
            self.domain_entry.delete(0, 'end')
            self.load_domains()
            
        except Exception as e:
            messagebox.showerror(self.t("error"), f"Ошибка добавления домена:\n{str(e)}")
    
    def remove_domain(self):
        """Remove selected domain from list"""
        try:
            # Get selected text
            try:
                selected_text = self.domains_textbox.selection_get()
            except:
                messagebox.showwarning(self.t("error"), "Выделите домен для удаления")
                return
            
            domain = selected_text.strip()
            if not domain:
                messagebox.showwarning(self.t("error"), "Выделите домен для удаления")
                return
            
            response = messagebox.askyesno(
                self.t("remove_button"),
                f"Удалить домен: {domain}?"
            )
            
            if not response:
                return
            
            list_file = self.appfiles_dir / "lists" / "list-general.txt"
            if not list_file.exists():
                list_file = self.script_dir / "lists" / "list-general.txt"
            
            if list_file.exists():
                with open(list_file, 'r', encoding='utf-8', errors='ignore') as f:
                    lines = f.readlines()
                
                # Remove the domain
                new_lines = [line for line in lines if line.strip() != domain]
                
                with open(list_file, 'w', encoding='utf-8') as f:
                    f.writelines(new_lines)
                
                messagebox.showinfo(self.t("success"), f"{self.t('domain_removed')}: {domain}")
                self.load_domains()
            
        except Exception as e:
            messagebox.showerror(self.t("error"), f"Ошибка удаления домена:\n{str(e)}")
    
    def create_settings_page(self):
        """Create settings page"""
        page = ctk.CTkScrollableFrame(self.main_frame)
        page.grid_columnconfigure(0, weight=1)
        
        # Title
        title = ctk.CTkLabel(
            page, 
            text=self.t("settings_title"), 
            font=ctk.CTkFont(size=28, weight="bold")
        )
        title.grid(row=0, column=0, padx=30, pady=(30, 20), sticky="w")
        
        # Game Filter
        game_frame = ctk.CTkFrame(page)
        game_frame.grid(row=1, column=0, padx=30, pady=10, sticky="ew")
        game_frame.grid_columnconfigure(0, weight=1)
        
        game_label = ctk.CTkLabel(
            game_frame,
            text="🎮 Game Filter",
            font=ctk.CTkFont(size=18, weight="bold")
        )
        game_label.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="w")
        
        game_desc = ctk.CTkLabel(
            game_frame,
            text=self.t("game_filter_desc"),
            font=ctk.CTkFont(size=12),
            text_color="gray"
        )
        game_desc.grid(row=1, column=0, padx=20, pady=(0, 10), sticky="w")
        
        self.game_filter_var = ctk.StringVar(value=self.get_game_filter_status())
        game_options = ctk.CTkSegmentedButton(
            game_frame,
            values=["Disabled", "TCP and UDP", "TCP only", "UDP only"],
            variable=self.game_filter_var,
            command=self.set_game_filter
        )
        game_options.grid(row=2, column=0, padx=20, pady=(0, 20), sticky="ew")
        
        # IPSet Filter
        ipset_frame = ctk.CTkFrame(page)
        ipset_frame.grid(row=2, column=0, padx=30, pady=10, sticky="ew")
        ipset_frame.grid_columnconfigure(0, weight=1)
        
        ipset_label = ctk.CTkLabel(
            ipset_frame,
            text="🌐 IPSet Filter",
            font=ctk.CTkFont(size=18, weight="bold")
        )
        ipset_label.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="w")
        
        ipset_desc = ctk.CTkLabel(
            ipset_frame,
            text=self.t("ipset_filter_desc"),
            font=ctk.CTkFont(size=12),
            text_color="gray"
        )
        ipset_desc.grid(row=1, column=0, padx=20, pady=(0, 10), sticky="w")
        
        self.ipset_filter_var = ctk.StringVar(value=self.get_ipset_status())
        ipset_options = ctk.CTkSegmentedButton(
            ipset_frame,
            values=["None", "Loaded", "Any"],
            variable=self.ipset_filter_var,
            command=self.set_ipset_filter
        )
        ipset_options.grid(row=2, column=0, padx=20, pady=(0, 20), sticky="ew")
        
        # Auto-Update Check
        update_frame = ctk.CTkFrame(page)
        update_frame.grid(row=3, column=0, padx=30, pady=10, sticky="ew")
        update_frame.grid_columnconfigure(0, weight=1)
        
        update_label = ctk.CTkLabel(
            update_frame,
            text="🔄 Auto-Update Check",
            font=ctk.CTkFont(size=18, weight="bold")
        )
        update_label.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="w")
        
        self.auto_update_var = ctk.BooleanVar(value=self.get_auto_update_status())
        update_switch = ctk.CTkSwitch(
            update_frame,
            text=self.t("enable_auto_update"),
            variable=self.auto_update_var,
            command=self.toggle_auto_update
        )
        update_switch.grid(row=1, column=0, padx=20, pady=(0, 20), sticky="w")
        
        self.pages["settings"] = page
    
    def create_updates_page(self):
        """Create updates page"""
        page = ctk.CTkFrame(self.main_frame)
        page.grid_columnconfigure(0, weight=1)
        
        # Title
        title = ctk.CTkLabel(
            page, 
            text=self.t("updates_title"), 
            font=ctk.CTkFont(size=28, weight="bold")
        )
        title.grid(row=0, column=0, padx=30, pady=(30, 20), sticky="w")
        
        # Update buttons
        buttons_frame = ctk.CTkFrame(page)
        buttons_frame.grid(row=1, column=0, padx=30, pady=10, sticky="ew")
        buttons_frame.grid_columnconfigure(0, weight=1)
        
        btn_ipset = ctk.CTkButton(
            buttons_frame,
            text="📋 Update IPSet List",
            command=self.update_ipset,
            height=50,
            font=ctk.CTkFont(size=14)
        )
        btn_ipset.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="ew")
        
        btn_hosts = ctk.CTkButton(
            buttons_frame,
            text="📝 Update Hosts File",
            command=self.update_hosts,
            height=50,
            font=ctk.CTkFont(size=14)
        )
        btn_hosts.grid(row=1, column=0, padx=20, pady=10, sticky="ew")
        
        btn_check = ctk.CTkButton(
            buttons_frame,
            text="🔍 Check for Updates",
            command=self.check_updates,
            height=50,
            font=ctk.CTkFont(size=14)
        )
        btn_check.grid(row=2, column=0, padx=20, pady=(10, 20), sticky="ew")
        
        # Info
        info_frame = ctk.CTkFrame(page)
        info_frame.grid(row=2, column=0, padx=30, pady=10, sticky="nsew")
        info_frame.grid_columnconfigure(0, weight=1)
        
        info_label = ctk.CTkLabel(
            info_frame,
            text="ℹ️ Update Information",
            font=ctk.CTkFont(size=18, weight="bold")
        )
        info_label.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="w")
        
        info_text = ctk.CTkTextbox(info_frame, height=200)
        info_text.grid(row=1, column=0, padx=20, pady=(0, 20), sticky="nsew")
        info_text.insert("1.0",
            "IPSet List: Updates the list of IP addresses to bypass\n\n"
            "Hosts File: Updates hosts file for Telegram web and Discord voice chat\n\n"
            "Check for Updates: Checks if a new version of Zapret is available"
        )
        info_text.configure(state="disabled")
        
        self.pages["updates"] = page

    def create_tools_page(self):
        """Create tools page"""
        page = ctk.CTkFrame(self.main_frame)
        page.grid_columnconfigure(0, weight=1)
        page.grid_rowconfigure(2, weight=1)
        
        # Title
        title = ctk.CTkLabel(
            page, 
            text=self.t("tools_title"), 
            font=ctk.CTkFont(size=28, weight="bold")
        )
        title.grid(row=0, column=0, padx=30, pady=(30, 20), sticky="w")
        
        # Tool buttons
        buttons_frame = ctk.CTkFrame(page)
        buttons_frame.grid(row=1, column=0, padx=30, pady=10, sticky="ew")
        buttons_frame.grid_columnconfigure((0, 1, 2), weight=1)
        
        btn_diagnostics = ctk.CTkButton(
            buttons_frame,
            text="🩺 " + self.t("run_diagnostics"),
            command=self.run_diagnostics,
            height=50,
            font=ctk.CTkFont(size=14)
        )
        btn_diagnostics.grid(row=0, column=0, padx=(20, 10), pady=20, sticky="ew")
        
        btn_tests = ctk.CTkButton(
            buttons_frame,
            text=self.t("run_tests"),
            command=self.run_tests,
            height=50,
            font=ctk.CTkFont(size=14)
        )
        btn_tests.grid(row=0, column=1, padx=(10, 10), pady=20, sticky="ew")
        
        btn_auto_select = ctk.CTkButton(
            buttons_frame,
            text=self.t("auto_select"),
            command=self.auto_select_strategy,
            height=50,
            font=ctk.CTkFont(size=14),
            fg_color="#FF9800",
            hover_color="#F57C00"
        )
        btn_auto_select.grid(row=0, column=2, padx=(10, 20), pady=20, sticky="ew")
        
        # Output console
        console_label = ctk.CTkLabel(
            page,
            text=self.t("console_output"),
            font=ctk.CTkFont(size=18, weight="bold")
        )
        console_label.grid(row=2, column=0, padx=30, pady=(10, 5), sticky="w")
        
        self.console_output = ctk.CTkTextbox(page, height=300)
        self.console_output.grid(row=3, column=0, padx=30, pady=(0, 20), sticky="nsew")
        
        self.pages["tools"] = page
    
    def create_about_page(self):
        """Create about page"""
        page = ctk.CTkScrollableFrame(self.main_frame)
        page.grid_columnconfigure(0, weight=1)
        
        # Title
        title = ctk.CTkLabel(
            page, 
            text=self.t("about_title"), 
            font=ctk.CTkFont(size=28, weight="bold")
        )
        title.grid(row=0, column=0, padx=30, pady=(30, 20), sticky="w")
        
        # Copyright section
        copyright_frame = ctk.CTkFrame(page)
        copyright_frame.grid(row=1, column=0, padx=30, pady=10, sticky="ew")
        copyright_frame.grid_columnconfigure(0, weight=1)
        
        copyright_label = ctk.CTkLabel(
            copyright_frame,
            text="📜 " + self.t("copyright"),
            font=ctk.CTkFont(size=18, weight="bold")
        )
        copyright_label.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="w")
        
        copyright_text = ctk.CTkTextbox(copyright_frame, height=120)
        copyright_text.grid(row=1, column=0, padx=20, pady=(0, 20), sticky="ew")
        copyright_text.insert("1.0",
            "Copyright (c) 2016-2026 bol-van\n"
            "Copyright (c) 2024-2026 Flowseal\n\n"
            "Программа сделана @flaynewww (telegram: t.me/javaold)\n"
            "По вопросам обращайтесь в Telegram"
        )
        copyright_text.configure(state="disabled")
        
        # License section
        license_frame = ctk.CTkFrame(page)
        license_frame.grid(row=2, column=0, padx=30, pady=10, sticky="ew")
        license_frame.grid_columnconfigure(0, weight=1)
        
        license_label = ctk.CTkLabel(
            license_frame,
            text="⚖️ " + self.t("license"),
            font=ctk.CTkFont(size=18, weight="bold")
        )
        license_label.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="w")
        
        license_text = ctk.CTkTextbox(license_frame, height=200)
        license_text.grid(row=1, column=0, padx=20, pady=(0, 20), sticky="ew")
        license_text.insert("1.0",
            "Код, заимствованный из проекта Zapret, распространяется под лицензией MIT.\n\n"
            "Сделано с использованием Zapret / в том числе и в нем использованным WinDivert.\n\n"
            "Данная программа включает в себя бинарные файлы WinDivert "
            "(https://github.com/basil00/WinDivert), которые распространяются на условиях "
            "двойной лицензии: GNU Lesser General Public License (LGPL) версии 3 или "
            "GNU General Public License (GPL) версии 2.\n\n"
            "Исходный код WinDivert доступен по ссылке выше.\n\n"
            "Программа полностью бесплатна и не имеет рекламы."
        )
        license_text.configure(state="disabled")
        
        # Quick Start section
        quickstart_frame = ctk.CTkFrame(page)
        quickstart_frame.grid(row=3, column=0, padx=30, pady=10, sticky="ew")
        quickstart_frame.grid_columnconfigure(0, weight=1)
        
        quickstart_label = ctk.CTkLabel(
            quickstart_frame,
            text="🚀 " + self.t("quick_start"),
            font=ctk.CTkFont(size=18, weight="bold")
        )
        quickstart_label.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="w")
        
        quickstart_text = ctk.CTkTextbox(quickstart_frame, height=200)
        quickstart_text.grid(row=1, column=0, padx=20, pady=(0, 20), sticky="ew")
        quickstart_text.insert("1.0",
            "ДЛЯ ЗАПУСКА:\n\n"
            "1. Запустите FLbuster.exe от имени администратора\n\n"
            "2. Нажмите либо окно \"Службы\" либо на главном окне \"Установить службу\"\n\n"
            "3. Выберите подходящую стратегию\n"
            "   Рекомендуемые: (ALT) / (ALT 9) / (FAKE TLS AUTO 3)\n\n"
            "4. Нажмите \"Test Strategy\" (чтобы протестировать)\n"
            "   или \"Install Selected Strategy\" (чтобы установить в режим службы Windows)\n\n"
            "P.S. При удалении сервиса Windows есть кнопка \"Remove Services\" снизу."
        )
        quickstart_text.configure(state="disabled")
        
        # Instructions section
        instructions_frame = ctk.CTkFrame(page)
        instructions_frame.grid(row=4, column=0, padx=30, pady=10, sticky="ew")
        instructions_frame.grid_columnconfigure(0, weight=1)
        
        instructions_label = ctk.CTkLabel(
            instructions_frame,
            text="📖 " + self.t("instructions"),
            font=ctk.CTkFont(size=18, weight="bold")
        )
        instructions_label.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="w")
        
        # Tabview for different instruction sections
        tabview = ctk.CTkTabview(instructions_frame, height=300)
        tabview.grid(row=1, column=0, padx=20, pady=(0, 20), sticky="ew")
        
        # Tab 1: Основы
        tab1 = tabview.add("Основы")
        basics_text = ctk.CTkTextbox(tab1, height=250)
        basics_text.pack(fill="both", expand=True, padx=10, pady=10)
        basics_text.insert("1.0",
            "ОСНОВНЫЕ ФУНКЦИИ:\n\n"
            "🏠 Главная - статус службы и быстрые действия\n\n"
            "⚙️ Службы - установка и управление службами\n\n"
            "🌐 Домены - добавление доменов для обхода\n\n"
            "🎮 Настройки - игровой фильтр, IPSet, автообновления\n\n"
            "🔄 Обновления - обновление списков и проверка версий\n\n"
            "🛠️ Инструменты - диагностика и тесты\n\n"
            "ℹ️ О программе - информация и инструкции"
        )
        basics_text.configure(state="disabled")
        
        # Tab 2: Стратегии
        tab2 = tabview.add("Стратегии")
        strategies_text = ctk.CTkTextbox(tab2, height=250)
        strategies_text.pack(fill="both", expand=True, padx=10, pady=10)
        strategies_text.insert("1.0",
            "ВЫБОР СТРАТЕГИИ:\n\n"
            "general.bat - основная стратегия\n\n"
            "general (ALT).bat - альтернативная (рекомендуется)\n\n"
            "general (ALT9).bat - еще один вариант (рекомендуется)\n\n"
            "general (FAKE TLS AUTO 3).bat - с поддельным TLS (рекомендуется)\n\n"
            "Если одна стратегия не работает - попробуйте другую!\n\n"
            "Используйте \"Test Strategy\" для проверки перед установкой."
        )
        strategies_text.configure(state="disabled")
        
        # Tab 3: Домены
        tab3 = tabview.add("Домены")
        domains_text = ctk.CTkTextbox(tab3, height=250)
        domains_text.pack(fill="both", expand=True, padx=10, pady=10)
        domains_text.insert("1.0",
            "ДОБАВЛЕНИЕ ДОМЕНОВ:\n\n"
            "1. Перейдите на вкладку \"🌐 Домены\"\n\n"
            "2. Введите домен (например: discord.com)\n\n"
            "3. Нажмите \"➕ Добавить\"\n\n"
            "4. Перезапустите службу\n\n"
            "ФОРМАТЫ:\n"
            "discord.com - точное совпадение\n"
            "*.discord.com - все поддомены\n"
            "*discord* - содержит discord\n\n"
            "После изменений обязательно перезапустите службу!"
        )
        domains_text.configure(state="disabled")
        
        # Tab 4: Проблемы
        tab4 = tabview.add("Проблемы")
        problems_text = ctk.CTkTextbox(tab4, height=250)
        problems_text.pack(fill="both", expand=True, padx=10, pady=10)
        problems_text.insert("1.0",
            "РЕШЕНИЕ ПРОБЛЕМ:\n\n"
            "Не работает Discord/YouTube:\n"
            "1. Включите Secure DNS в браузере\n"
            "2. Попробуйте другую стратегию\n"
            "3. Запустите диагностику (Tools → Run Diagnostics)\n"
            "4. Очистите кэш Discord\n\n"
            "Служба не устанавливается:\n"
            "1. Запустите от администратора\n"
            "2. Проверьте наличие appfiles/bin/winws.exe\n"
            "3. Отключите антивирус временно\n\n"
            "Конфликты:\n"
            "1. Удалите GoodbyeDPI, Adguard\n"
            "2. Запустите Check Status для поиска конфликтов\n"
            "3. Используйте Run Diagnostics"
        )
        problems_text.configure(state="disabled")
        
        # Tab 5: Контакты
        tab5 = tabview.add("Контакты")
        contact_text = ctk.CTkTextbox(tab5, height=250)
        contact_text.pack(fill="both", expand=True, padx=10, pady=10)
        contact_text.insert("1.0",
            "КОНТАКТЫ И ССЫЛКИ:\n\n"
            "Автор GUI: @flaynewww\n"
            "Telegram: t.me/javaold\n\n"
            "Оригинальный проект Zapret:\n"
            "GitHub: github.com/bol-van/zapret\n\n"
            "Форк Zapret-Discord-YouTube:\n"
            "GitHub: github.com/Flowseal/zapret-discord-youtube\n\n"
            "WinDivert:\n"
            "GitHub: github.com/basil00/WinDivert\n\n"
            "По всем вопросам обращайтесь в Telegram!"
        )
        contact_text.configure(state="disabled")
        
        self.pages["about"] = page
    
    def create_status_card(self, parent, title, status, row, col):
        """Create a status card widget"""
        card = ctk.CTkFrame(parent)
        card.grid(row=row, column=col, padx=10, pady=10, sticky="nsew")
        
        title_label = ctk.CTkLabel(
            card,
            text=title,
            font=ctk.CTkFont(size=14, weight="bold")
        )
        title_label.pack(padx=20, pady=(20, 5))
        
        status_label = ctk.CTkLabel(
            card,
            text=status,
            font=ctk.CTkFont(size=16)
        )
        status_label.pack(padx=20, pady=(5, 20))
        
        return {"frame": card, "status_label": status_label}
    
    def show_page(self, page_name):
        """Show selected page"""
        # Hide all pages
        for page in self.pages.values():
            page.grid_remove()
        
        # Show selected page
        if page_name in self.pages:
            self.pages[page_name].grid(row=0, column=0, sticky="nsew")
        
        # Update button colors
        for key, btn in self.nav_buttons.items():
            if key == page_name:
                btn.configure(fg_color=("gray75", "gray25"))
            else:
                btn.configure(fg_color="transparent")
    
    def change_appearance(self, mode):
        """Change appearance mode"""
        # Map translated names to actual modes
        mode_map = {
            self.t("dark"): "dark",
            self.t("light"): "light",
            self.t("system"): "system",
            "Dark": "dark",
            "Light": "light",
            "System": "system"
        }
        actual_mode = mode_map.get(mode, mode.lower())
        ctk.set_appearance_mode(actual_mode)
    
    def toggle_blur(self):
        """Toggle blur effect on window"""
        try:
            if self.blur_var.get():
                # Enable blur effect
                self.enable_blur()
            else:
                # Disable blur effect
                self.disable_blur()
        except Exception as e:
            print(f"Error toggling blur: {e}")
    
    def enable_blur(self):
        """Enable Windows Acrylic/Blur effect with better visuals"""
        try:
            import ctypes
            from ctypes import wintypes
            
            # Get window handle
            hwnd = ctypes.windll.user32.GetParent(self.winfo_id())
            if not hwnd:
                hwnd = self.winfo_id()
            
            # Store original state
            if not hasattr(self, '_blur_enabled'):
                self._blur_enabled = False
            
            # Windows 11/10 DWM API
            DWMWA_SYSTEMBACKDROP_TYPE = 38
            DWMWA_USE_IMMERSIVE_DARK_MODE = 20
            
            # Enable dark mode for better blur
            try:
                use_dark = ctypes.c_int(1)
                ctypes.windll.dwmapi.DwmSetWindowAttribute(
                    hwnd,
                    DWMWA_USE_IMMERSIVE_DARK_MODE,
                    ctypes.byref(use_dark),
                    ctypes.sizeof(use_dark)
                )
            except:
                pass
            
            # Try Windows 11 Acrylic effect (best quality)
            try:
                backdrop_type = ctypes.c_int(2)  # 2 = Acrylic (beautiful blur)
                result = ctypes.windll.dwmapi.DwmSetWindowAttribute(
                    hwnd,
                    DWMWA_SYSTEMBACKDROP_TYPE,
                    ctypes.byref(backdrop_type),
                    ctypes.sizeof(backdrop_type)
                )
                if result == 0:
                    self._blur_enabled = True
                    self._blur_method = 'acrylic'
            except Exception as e:
                print(f"Acrylic failed: {e}")
            
            # Fallback: Windows 10 Blur Behind effect
            if not self._blur_enabled:
                try:
                    class ACCENTPOLICY(ctypes.Structure):
                        _fields_ = [
                            ("AccentState", ctypes.c_int),
                            ("AccentFlags", ctypes.c_int),
                            ("GradientColor", ctypes.c_int),
                            ("AnimationId", ctypes.c_int)
                        ]
                    
                    class WINCOMPATTRDATA(ctypes.Structure):
                        _fields_ = [
                            ("Attribute", ctypes.c_int),
                            ("Data", ctypes.POINTER(ACCENTPOLICY)),
                            ("SizeOfData", ctypes.c_size_t)
                        ]
                    
                    accent = ACCENTPOLICY()
                    accent.AccentState = 3  # ACCENT_ENABLE_BLURBEHIND
                    accent.AccentFlags = 2  # Draw all borders
                    # Beautiful gradient color (dark with transparency)
                    accent.GradientColor = 0xCC000000  # AABBGGRR format (80% opacity, black)
                    accent.AnimationId = 0
                    
                    data = WINCOMPATTRDATA()
                    data.Attribute = 19  # WCA_ACCENT_POLICY
                    data.Data = ctypes.pointer(accent)
                    data.SizeOfData = ctypes.sizeof(accent)
                    
                    ctypes.windll.user32.SetWindowCompositionAttribute(hwnd, ctypes.byref(data))
                    self._blur_enabled = True
                    self._blur_method = 'blurbehind'
                except Exception as e:
                    print(f"BlurBehind failed: {e}")
            
            # Set transparency for better effect (90% visible)
            self.attributes('-alpha', 0.90)
            
            # Update window to apply changes
            self.update_idletasks()
                
        except Exception as e:
            print(f"Error enabling blur: {e}")
            self._blur_enabled = False
    
    def disable_blur(self):
        """Disable blur effect completely"""
        try:
            import ctypes
            
            # Get window handle
            hwnd = ctypes.windll.user32.GetParent(self.winfo_id())
            if not hwnd:
                hwnd = self.winfo_id()
            
            # Disable Windows 11 Acrylic/Mica effect
            try:
                backdrop_type = ctypes.c_int(1)  # 1 = None/Auto (disable)
                DWMWA_SYSTEMBACKDROP_TYPE = 38
                ctypes.windll.dwmapi.DwmSetWindowAttribute(
                    hwnd,
                    DWMWA_SYSTEMBACKDROP_TYPE,
                    ctypes.byref(backdrop_type),
                    ctypes.sizeof(backdrop_type)
                )
            except:
                pass
            
            # Disable Windows 10 Blur Behind effect
            try:
                class ACCENTPOLICY(ctypes.Structure):
                    _fields_ = [
                        ("AccentState", ctypes.c_int),
                        ("AccentFlags", ctypes.c_int),
                        ("GradientColor", ctypes.c_int),
                        ("AnimationId", ctypes.c_int)
                    ]
                
                class WINCOMPATTRDATA(ctypes.Structure):
                    _fields_ = [
                        ("Attribute", ctypes.c_int),
                        ("Data", ctypes.POINTER(ACCENTPOLICY)),
                        ("SizeOfData", ctypes.c_size_t)
                    ]
                
                accent = ACCENTPOLICY()
                accent.AccentState = 0  # ACCENT_DISABLED
                accent.AccentFlags = 0
                accent.GradientColor = 0
                accent.AnimationId = 0
                
                data = WINCOMPATTRDATA()
                data.Attribute = 19  # WCA_ACCENT_POLICY
                data.Data = ctypes.pointer(accent)
                data.SizeOfData = ctypes.sizeof(accent)
                
                ctypes.windll.user32.SetWindowCompositionAttribute(hwnd, ctypes.byref(data))
            except:
                pass
            
            # Reset transparency to fully opaque
            self.attributes('-alpha', 1.0)
            
            # Force window refresh
            self.update_idletasks()
            
            # Mark as disabled
            self._blur_enabled = False
            
        except Exception as e:
            print(f"Error disabling blur: {e}")
    
    def get_available_strategies(self):
        """Get list of available .bat strategy files"""
        strategies = []
        try:
            # Check in appfiles directory first
            appfiles_dir = self.script_dir / "appfiles"
            if appfiles_dir.exists():
                for file in appfiles_dir.glob("*.bat"):
                    if not file.name.startswith("service") and not file.name.startswith("check"):
                        strategies.append(file.name)
            
            # Fallback to root directory
            if not strategies:
                for file in self.script_dir.glob("*.bat"):
                    if not file.name.startswith("service") and not file.name.startswith("FLbuster") and not file.name.startswith("Install") and not file.name.startswith("Build") and not file.name.startswith("organize") and not file.name.startswith("check"):
                        strategies.append(file.name)
            
            strategies.sort()
        except Exception as e:
            print(f"Error getting strategies: {e}")
            print(f"Script dir: {self.script_dir}")
            print(f"Appfiles dir: {self.script_dir / 'appfiles'}")
        return strategies if strategies else ["No strategies found"]
    
    def run_command(self, command, show_output=True):
        """Run a command and optionally show output"""
        try:
            if show_output and "tools" in self.pages:
                self.console_output.delete("1.0", "end")
                self.console_output.insert("1.0", f"Running: {command}\n\n")
            
            # Use cp866 encoding for Windows console commands
            result = subprocess.run(
                command,
                shell=True,
                cwd=str(self.script_dir),
                capture_output=True,
                text=True,
                encoding='cp866',  # Windows console encoding
                errors='replace'
            )
            
            output = result.stdout + result.stderr
            
            if show_output and "tools" in self.pages:
                self.console_output.insert("end", output)
            
            return result.returncode == 0, output
        except Exception as e:
            error_msg = f"Error running command: {str(e)}"
            if show_output and "tools" in self.pages:
                self.console_output.insert("end", f"\n{error_msg}")
            return False, error_msg
    
    def install_service(self):
        """Install selected service strategy"""
        strategy = self.strategy_var.get()
        if not strategy or strategy == "No strategies found":
            messagebox.showerror(self.t("error"), self.t("no_strategy"))
            return
        
        response = messagebox.askyesno(
            self.t("install_confirm"),
            self.t("install_confirm_text").format(strategy)
        )
        
        if response:
            threading.Thread(
                target=self._install_service_thread,
                args=(strategy,),
                daemon=True
            ).start()
    
    def test_strategy(self):
        """Test selected strategy without installing as service"""
        strategy = self.strategy_var.get()
        if not strategy or strategy == "No strategies found":
            messagebox.showerror(self.t("error"), self.t("no_strategy"))
            return
        
        response = messagebox.askyesno(
            "Test Strategy",
            f"Run '{strategy}' manually for testing?\n\n"
            "This will start the bypass in a separate window.\n"
            "Close the window to stop the bypass.\n\n"
            "Note: This is for testing only. Use 'Install Service' for permanent installation."
        )
        
        if response:
            threading.Thread(
                target=self._test_strategy_thread,
                args=(strategy,),
                daemon=True
            ).start()
    
    def _test_strategy_thread(self, strategy):
        """Test strategy in background thread"""
        try:
            # Find the strategy file
            strategy_path = None
            
            # Check in appfiles first
            appfiles_strategy = self.appfiles_dir / strategy
            if appfiles_strategy.exists():
                strategy_path = appfiles_strategy
            else:
                # Check in root
                root_strategy = self.script_dir / strategy
                if root_strategy.exists():
                    strategy_path = root_strategy
            
            if not strategy_path:
                messagebox.showerror(
                    self.t("error"),
                    f"Strategy file not found: {strategy}"
                )
                return
            
            # Run the strategy file directly
            subprocess.Popen(
                [str(strategy_path)],
                cwd=str(strategy_path.parent),
                creationflags=subprocess.CREATE_NEW_CONSOLE
            )
            
            messagebox.showinfo(
                "Test Strategy",
                f"Strategy '{strategy}' started in a new window.\n\n"
                "Close the window to stop the bypass.\n\n"
                "If it works, you can install it as a service for automatic startup."
            )
            
        except Exception as e:
            messagebox.showerror(
                self.t("error"),
                f"Failed to test strategy:\n{str(e)}"
            )
    
    def _install_service_thread(self, strategy):
        """Install service in background thread"""
        try:
            # Find the strategy file
            strategy_path = None

            # Check in appfiles first
            appfiles_strategy = self.appfiles_dir / strategy
            if appfiles_strategy.exists():
                strategy_path = appfiles_strategy
            else:
                # Check in root
                root_strategy = self.script_dir / strategy
                if root_strategy.exists():
                    strategy_path = root_strategy

            if not strategy_path:
                messagebox.showerror(
                    self.t("error"),
                    f"Strategy file not found: {strategy}"
                )
                return

            # Stop existing services first
            subprocess.run('sc stop zapret', shell=True, capture_output=True)
            subprocess.run('sc delete zapret', shell=True, capture_output=True)
            subprocess.run('taskkill /IM winws.exe /F', shell=True, capture_output=True)

            # Parse the strategy file to extract winws.exe arguments
            bin_path = self.appfiles_dir / "bin"
            if not bin_path.exists():
                bin_path = self.script_dir / "bin"

            lists_path = self.appfiles_dir / "lists"
            if not lists_path.exists():
                lists_path = self.script_dir / "lists"

            # Read strategy file and extract winws.exe command
            with open(strategy_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()

            # Find the winws.exe command line
            args = []
            capture = False
            for line in content.split('\n'):
                # Look for winws.exe in the line
                if 'winws.exe' in line.lower():
                    capture = True
                    # Extract everything after winws.exe
                    # Handle both direct call and start command
                    if 'start' in line.lower():
                        # Format: start "title" /min "%BIN%winws.exe" args...
                        parts = line.split('winws.exe', 1)
                        if len(parts) > 1:
                            args_part = parts[1].strip()
                    else:
                        # Direct call: "%BIN%winws.exe" args...
                        parts = line.split('winws.exe', 1)
                        if len(parts) > 1:
                            args_part = parts[1].strip()
                    
                    # Clean up the arguments
                    if 'args_part' in locals():
                        args_part = args_part.replace('"', '').replace('^', '').strip()
                        if args_part:
                            args.append(args_part)
                elif capture:
                    # Continue capturing multi-line command
                    line_clean = line.strip()
                    # Stop if we hit an empty line or new command
                    if not line_clean or (line_clean and not line_clean.startswith('--') and '^' not in line):
                        break
                    line_clean = line_clean.replace('^', '').strip()
                    if line_clean:
                        args.append(line_clean)

            # Join all arguments
            full_args = ' '.join(args)

            # Replace path variables
            full_args = full_args.replace('%BIN%', str(bin_path) + '\\')
            full_args = full_args.replace('%LISTS%', str(lists_path) + '\\')
            full_args = full_args.replace('%GameFilterTCP%', '12')
            full_args = full_args.replace('%GameFilterUDP%', '12')
            full_args = full_args.replace('%GameFilter%', '12')

            # Build the service command
            winws_exe = bin_path / "winws.exe"
            if not winws_exe.exists():
                messagebox.showerror(
                    self.t("error"),
                    f"winws.exe not found at: {winws_exe}"
                )
                return

            service_cmd = f'"{winws_exe}" {full_args}'

            # Create the service
            create_cmd = f'sc create zapret binPath= "{service_cmd}" DisplayName= "zapret" start= auto'
            result = subprocess.run(create_cmd, shell=True, capture_output=True, text=True)

            if result.returncode != 0:
                messagebox.showerror(
                    self.t("error"),
                    f"Failed to create service:\n{result.stderr}"
                )
                return

            # Set description
            subprocess.run(
                'sc description zapret "Zapret DPI bypass software"',
                shell=True,
                capture_output=True
            )

            # Save strategy name to registry
            strategy_name = strategy.replace('.bat', '')
            subprocess.run(
                f'reg add "HKLM\\System\\CurrentControlSet\\Services\\zapret" /v zapret-discord-youtube /t REG_SZ /d "{strategy_name}" /f',
                shell=True,
                capture_output=True
            )

            # Start the service
            start_result = subprocess.run(
                'sc start zapret',
                shell=True,
                capture_output=True,
                text=True
            )

            if start_result.returncode == 0 or "START_PENDING" in start_result.stdout or "RUNNING" in start_result.stdout:
                messagebox.showinfo(
                    self.t("success"),
                    f"Service installed successfully!\n\nStrategy: {strategy}\n\nCheck Dashboard for status."
                )
            else:
                messagebox.showwarning(
                    self.t("success"),
                    f"Service created but may need manual start.\n\nStrategy: {strategy}\n\nUse 'sc start zapret' to start manually."
                )

            self.update_status()

        except Exception as e:
            messagebox.showerror(
                self.t("error"),
                f"Failed to install service:\n{str(e)}"
            )

    
    def remove_services(self):
        """Remove installed services"""
        response = messagebox.askyesno(
            self.t("remove_confirm"),
            self.t("remove_confirm_text")
        )
        
        if response:
            threading.Thread(
                target=self._remove_services_thread,
                daemon=True
            ).start()
    
    def _remove_services_thread(self):
        """Remove services in background thread"""
        try:
            # Stop and remove zapret service
            commands = [
                'sc stop zapret',
                'sc delete zapret',
                'taskkill /IM winws.exe /F',
                'sc stop WinDivert',
                'sc delete WinDivert',
                'sc stop WinDivert14',
                'sc delete WinDivert14'
            ]
            
            for cmd in commands:
                subprocess.run(
                    cmd,
                    shell=True,
                    capture_output=True,
                    text=True
                )
            
            messagebox.showinfo(
                self.t("success"),
                self.t("services_removed")
            )
            self.update_status()
            
        except Exception as e:
            messagebox.showerror(
                self.t("error"),
                f"{self.t('failed_remove')}\n{str(e)}"
            )
    
    def check_status(self):
        """Check service status with detailed information"""
        self.update_status()
        
        # Gather detailed status information
        status_info = []
        
        # 1. Check zapret service
        success, output = self.run_command('sc query "zapret"', show_output=False)
        if "RUNNING" in output:
            status_info.append("✅ Служба zapret: ЗАПУЩЕНА")
            
            # Try to get strategy name from registry
            success_reg, reg_output = self.run_command(
                'reg query "HKLM\\System\\CurrentControlSet\\Services\\zapret" /v zapret-discord-youtube',
                show_output=False
            )
            if success_reg and "REG_SZ" in reg_output:
                try:
                    strategy_name = reg_output.split("REG_SZ")[1].strip()
                    status_info.append(f"   Стратегия: {strategy_name}")
                except:
                    pass
        elif "STOPPED" in output:
            status_info.append("⚠️ Служба zapret: ОСТАНОВЛЕНА")
        else:
            status_info.append("❌ Служба zapret: НЕ УСТАНОВЛЕНА")
        
        # 2. Check winws.exe process
        success, output = self.run_command('tasklist /FI "IMAGENAME eq winws.exe" /FO LIST', show_output=False)
        if "winws.exe" in output:
            status_info.append("✅ Процесс winws.exe: АКТИВЕН")
            # Try to get PID
            for line in output.split('\n'):
                if "PID:" in line:
                    pid = line.split("PID:")[1].strip()
                    status_info.append(f"   PID: {pid}")
                    break
        else:
            status_info.append("❌ Процесс winws.exe: НЕ ЗАПУЩЕН")
        
        # 3. Check WinDivert service
        success, output = self.run_command('sc query "WinDivert"', show_output=False)
        if "RUNNING" in output:
            status_info.append("✅ WinDivert: ЗАПУЩЕН")
        elif "STOPPED" in output:
            status_info.append("⚠️ WinDivert: ОСТАНОВЛЕН")
        else:
            status_info.append("ℹ️ WinDivert: Не установлен (нормально)")
        
        # 4. Check Base Filtering Engine
        success, output = self.run_command('sc query "BFE"', show_output=False)
        if "RUNNING" in output:
            status_info.append("✅ Base Filtering Engine: ЗАПУЩЕН")
        else:
            status_info.append("❌ Base Filtering Engine: НЕ ЗАПУЩЕН (требуется!)")
        
        # 5. Check TCP timestamps
        success, output = self.run_command('netsh interface tcp show global', show_output=False)
        if "Receive-Side Scaling State" in output:
            if "timestamps" in output.lower():
                for line in output.split('\n'):
                    if "timestamp" in line.lower():
                        if "enabled" in line.lower():
                            status_info.append("✅ TCP Timestamps: ВКЛЮЧЕНЫ")
                        else:
                            status_info.append("⚠️ TCP Timestamps: ВЫКЛЮЧЕНЫ")
                        break
        
        # 6. Check game filter status
        game_status = self.get_game_filter_status()
        status_info.append(f"ℹ️ Игровой фильтр: {game_status}")
        
        # 7. Check IPSet filter status
        ipset_status = self.get_ipset_status()
        status_info.append(f"ℹ️ IPSet фильтр: {ipset_status}")
        
        # 8. Check auto-update status
        auto_update = "Включен" if self.get_auto_update_status() else "Выключен"
        status_info.append(f"ℹ️ Автообновления: {auto_update}")
        
        # 9. Check for conflicting services
        conflicts = []
        for service in ["GoodbyeDPI", "AdguardSvc", "SmartByte"]:
            success, output = self.run_command(f'sc query "{service}"', show_output=False)
            if "RUNNING" in output:
                conflicts.append(service)
        
        if conflicts:
            status_info.append(f"⚠️ КОНФЛИКТЫ: {', '.join(conflicts)}")
            status_info.append("   Рекомендуется остановить эти службы")
        
        # Display status
        status_text = "\n".join(status_info)
        
        # Create custom dialog with more space
        dialog = ctk.CTkToplevel(self)
        dialog.title("Детальный статус системы")
        dialog.geometry("600x500")
        dialog.transient(self)
        dialog.grab_set()
        
        # Title
        title_label = ctk.CTkLabel(
            dialog,
            text="🔍 Детальный статус системы",
            font=ctk.CTkFont(size=20, weight="bold")
        )
        title_label.pack(padx=20, pady=(20, 10))
        
        # Status text
        status_textbox = ctk.CTkTextbox(dialog, height=350, font=ctk.CTkFont(size=13))
        status_textbox.pack(padx=20, pady=10, fill="both", expand=True)
        status_textbox.insert("1.0", status_text)
        status_textbox.configure(state="disabled")
        
        # Buttons frame
        button_frame = ctk.CTkFrame(dialog, fg_color="transparent")
        button_frame.pack(padx=20, pady=(0, 20), fill="x")
        
        # Refresh button
        refresh_btn = ctk.CTkButton(
            button_frame,
            text="🔄 Обновить",
            command=lambda: self._refresh_status_dialog(dialog, status_textbox),
            width=150
        )
        refresh_btn.pack(side="left", padx=(0, 10))
        
        # Close button
        close_btn = ctk.CTkButton(
            button_frame,
            text="Закрыть",
            command=dialog.destroy,
            width=150
        )
        close_btn.pack(side="left")
        
        # Center dialog
        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() // 2) - (dialog.winfo_width() // 2)
        y = (dialog.winfo_screenheight() // 2) - (dialog.winfo_height() // 2)
        dialog.geometry(f"+{x}+{y}")
    
    def _refresh_status_dialog(self, dialog, textbox):
        """Refresh status in dialog"""
        self.update_status()
        
        # Gather status again
        status_info = []
        
        # Zapret service
        success, output = self.run_command('sc query "zapret"', show_output=False)
        if "RUNNING" in output:
            status_info.append("✅ Служба zapret: ЗАПУЩЕНА")
            success_reg, reg_output = self.run_command(
                'reg query "HKLM\\System\\CurrentControlSet\\Services\\zapret" /v zapret-discord-youtube',
                show_output=False
            )
            if success_reg and "REG_SZ" in reg_output:
                try:
                    strategy_name = reg_output.split("REG_SZ")[1].strip()
                    status_info.append(f"   Стратегия: {strategy_name}")
                except:
                    pass
        elif "STOPPED" in output:
            status_info.append("⚠️ Служба zapret: ОСТАНОВЛЕНА")
        else:
            status_info.append("❌ Служба zapret: НЕ УСТАНОВЛЕНА")
        
        # winws.exe process
        success, output = self.run_command('tasklist /FI "IMAGENAME eq winws.exe" /FO LIST', show_output=False)
        if "winws.exe" in output:
            status_info.append("✅ Процесс winws.exe: АКТИВЕН")
            for line in output.split('\n'):
                if "PID:" in line:
                    pid = line.split("PID:")[1].strip()
                    status_info.append(f"   PID: {pid}")
                    break
        else:
            status_info.append("❌ Процесс winws.exe: НЕ ЗАПУЩЕН")
        
        # WinDivert
        success, output = self.run_command('sc query "WinDivert"', show_output=False)
        if "RUNNING" in output:
            status_info.append("✅ WinDivert: ЗАПУЩЕН")
        elif "STOPPED" in output:
            status_info.append("⚠️ WinDivert: ОСТАНОВЛЕН")
        else:
            status_info.append("ℹ️ WinDivert: Не установлен (нормально)")
        
        # BFE
        success, output = self.run_command('sc query "BFE"', show_output=False)
        if "RUNNING" in output:
            status_info.append("✅ Base Filtering Engine: ЗАПУЩЕН")
        else:
            status_info.append("❌ Base Filtering Engine: НЕ ЗАПУЩЕН (требуется!)")
        
        # TCP timestamps
        success, output = self.run_command('netsh interface tcp show global', show_output=False)
        if "timestamps" in output.lower():
            for line in output.split('\n'):
                if "timestamp" in line.lower():
                    if "enabled" in line.lower():
                        status_info.append("✅ TCP Timestamps: ВКЛЮЧЕНЫ")
                    else:
                        status_info.append("⚠️ TCP Timestamps: ВЫКЛЮЧЕНЫ")
                    break
        
        # Settings
        game_status = self.get_game_filter_status()
        status_info.append(f"ℹ️ Игровой фильтр: {game_status}")
        
        ipset_status = self.get_ipset_status()
        status_info.append(f"ℹ️ IPSet фильтр: {ipset_status}")
        
        auto_update = "Включен" if self.get_auto_update_status() else "Выключен"
        status_info.append(f"ℹ️ Автообновления: {auto_update}")
        
        # Conflicts
        conflicts = []
        for service in ["GoodbyeDPI", "AdguardSvc", "SmartByte"]:
            success, output = self.run_command(f'sc query "{service}"', show_output=False)
            if "RUNNING" in output:
                conflicts.append(service)
        
        if conflicts:
            status_info.append(f"⚠️ КОНФЛИКТЫ: {', '.join(conflicts)}")
            status_info.append("   Рекомендуется остановить эти службы")
        
        # Update textbox
        textbox.configure(state="normal")
        textbox.delete("1.0", "end")
        textbox.insert("1.0", "\n".join(status_info))
        textbox.configure(state="disabled")
    
    def update_status(self):
        """Update status information"""
        # Check if zapret service is running
        success, output = self.run_command('sc query "zapret"', show_output=False)
        if "RUNNING" in output:
            self.service_status_card["status_label"].configure(
                text=self.t("running"),
                text_color="green"
            )
        else:
            self.service_status_card["status_label"].configure(
                text=self.t("not_running"),
                text_color="red"
            )
        
        # Check if winws.exe is running
        success, output = self.run_command('tasklist /FI "IMAGENAME eq winws.exe"', show_output=False)
        if "winws.exe" in output:
            self.bypass_status_card["status_label"].configure(
                text=self.t("active"),
                text_color="green"
            )
        else:
            self.bypass_status_card["status_label"].configure(
                text=self.t("inactive"),
                text_color="red"
            )
    
    def get_game_filter_status(self):
        """Get current game filter status"""
        flag_file = self.appfiles_dir / "utils" / "game_filter.enabled"
        if not flag_file.exists():
            flag_file = self.script_dir / "utils" / "game_filter.enabled"
        if not flag_file.exists():
            return "Disabled"
        
        try:
            mode = flag_file.read_text().strip().lower()
            if mode == "all":
                return "TCP and UDP"
            elif mode == "tcp":
                return "TCP only"
            elif mode == "udp":
                return "UDP only"
        except:
            pass
        return "Disabled"
    
    def set_game_filter(self, value):
        """Set game filter mode"""
        flag_file = self.appfiles_dir / "utils" / "game_filter.enabled"
        if not flag_file.parent.exists():
            flag_file = self.script_dir / "utils" / "game_filter.enabled"
        
        try:
            if value == "Disabled":
                if flag_file.exists():
                    flag_file.unlink()
            elif value == "TCP and UDP":
                flag_file.write_text("all")
            elif value == "TCP only":
                flag_file.write_text("tcp")
            elif value == "UDP only":
                flag_file.write_text("udp")
            
            messagebox.showinfo(self.t("success"), self.t("game_filter_updated"))
        except Exception as e:
            messagebox.showerror(self.t("error"), f"Failed to update game filter: {e}")
    
    def get_ipset_status(self):
        """Get current IPSet filter status"""
        list_file = self.appfiles_dir / "lists" / "ipset-all.txt"
        if not list_file.exists():
            list_file = self.script_dir / "lists" / "ipset-all.txt"
        if not list_file.exists():
            return "None"
        
        try:
            content = list_file.read_text().strip()
            if not content:
                return "Any"
            elif "203.0.113.113/32" in content:
                return "None"
            else:
                return "Loaded"
        except:
            pass
        return "None"
    
    def set_ipset_filter(self, value):
        """Set IPSet filter mode"""
        list_file = self.appfiles_dir / "lists" / "ipset-all.txt"
        backup_file = self.appfiles_dir / "lists" / "ipset-all.txt.backup"
        
        if not list_file.parent.exists():
            list_file = self.script_dir / "lists" / "ipset-all.txt"
            backup_file = self.script_dir / "lists" / "ipset-all.txt.backup"
        
        try:
            if value == "None":
                if list_file.exists():
                    if not backup_file.exists():
                        list_file.rename(backup_file)
                    list_file.write_text("203.0.113.113/32\n")
            elif value == "Any":
                if list_file.exists():
                    if not backup_file.exists():
                        list_file.rename(backup_file)
                list_file.write_text("")
            elif value == "Loaded":
                if backup_file.exists():
                    if list_file.exists():
                        list_file.unlink()
                    backup_file.rename(list_file)
                else:
                    messagebox.showwarning(self.t("error"), "No backup found. Update IPSet list first.")
                    return
            
            messagebox.showinfo(self.t("success"), self.t("ipset_filter_updated"))
        except Exception as e:
            messagebox.showerror(self.t("error"), f"Failed to update IPSet filter: {e}")
    
    def get_auto_update_status(self):
        """Get auto-update check status"""
        flag_file = self.appfiles_dir / "utils" / "check_updates.enabled"
        if not flag_file.exists():
            flag_file = self.script_dir / "utils" / "check_updates.enabled"
        return flag_file.exists()
    
    def toggle_auto_update(self):
        """Toggle auto-update check"""
        flag_file = self.appfiles_dir / "utils" / "check_updates.enabled"
        if not flag_file.parent.exists():
            flag_file = self.script_dir / "utils" / "check_updates.enabled"
        
        try:
            if self.auto_update_var.get():
                flag_file.write_text("ENABLED")
            else:
                if flag_file.exists():
                    flag_file.unlink()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to toggle auto-update: {e}")
    
    def update_ipset(self):
        """Update IPSet list"""
        response = messagebox.askyesno(
            "Update IPSet",
            "Download the latest IPSet list from repository?"
        )
        
        if response:
            threading.Thread(target=self._update_ipset_thread, daemon=True).start()
    
    def _update_ipset_thread(self):
        """Update IPSet in background"""
        url = "https://raw.githubusercontent.com/Flowseal/zapret-discord-youtube/refs/heads/main/.service/ipset-service.txt"
        list_file = self.appfiles_dir / "lists" / "ipset-all.txt"
        if not list_file.parent.exists():
            list_file = self.script_dir / "lists" / "ipset-all.txt"
        
        try:
            import urllib.request
            urllib.request.urlretrieve(url, str(list_file))
            messagebox.showinfo("Success", "IPSet list updated successfully")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to update IPSet list: {e}")
    
    def update_hosts(self):
        """Update hosts file"""
        messagebox.showinfo(
            "Update Hosts",
            "Hosts file update requires manual steps.\n\n"
            "Please use appfiles/service.bat -> 'Update Hosts File' for this operation."
        )
    
    def check_updates(self):
        """Check for updates"""
        threading.Thread(target=self._check_updates_thread, daemon=True).start()
    
    def _check_updates_thread(self):
        """Check updates in background"""
        try:
            import urllib.request
            url = "https://raw.githubusercontent.com/Flowseal/zapret-discord-youtube/main/.service/version.txt"
            with urllib.request.urlopen(url, timeout=5) as response:
                github_version = response.read().decode('utf-8').strip()
            
            # Read local version from service.bat
            service_file = self.appfiles_dir / "service.bat"
            if not service_file.exists():
                service_file = self.script_dir / "service.bat"
            local_version = "Unknown"
            if service_file.exists():
                content = service_file.read_text(encoding='utf-8')
                for line in content.split('\n'):
                    if 'LOCAL_VERSION' in line and '=' in line:
                        local_version = line.split('=')[1].strip().strip('"')
                        break
            
            if local_version == github_version:
                messagebox.showinfo("Updates", f"You have the latest version: {local_version}")
            else:
                response = messagebox.askyesno(
                    "Update Available",
                    f"New version available: {github_version}\n"
                    f"Current version: {local_version}\n\n"
                    "Open download page?"
                )
                if response:
                    webbrowser.open("https://github.com/Flowseal/zapret-discord-youtube/releases/latest")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to check for updates: {e}")
    
    def run_diagnostics(self):
        """Run diagnostics"""
        self.show_page("tools")
        threading.Thread(target=self._run_diagnostics_thread, daemon=True).start()
    
    def _run_diagnostics_thread(self):
        """Run diagnostics in background"""
        self.console_output.delete("1.0", "end")
        self.console_output.insert("1.0", "═══════════════════════════════════════════════\n")
        self.console_output.insert("end", "  ДИАГНОСТИКА СИСТЕМЫ\n")
        self.console_output.insert("end", "═══════════════════════════════════════════════\n\n")
        
        # Run basic checks
        checks = [
            ('sc query BFE', "Base Filtering Engine (BFE)"),
            ('netsh interface tcp show global', "Настройки TCP"),
            ('sc query "zapret"', "Служба Zapret"),
            ('tasklist /FI "IMAGENAME eq winws.exe"', "Процесс winws.exe"),
        ]
        
        for cmd, name in checks:
            self.console_output.insert("end", f"▶ Проверка: {name}\n")
            self.console_output.insert("end", "─" * 50 + "\n")
            success, output = self.run_command(cmd, show_output=False)
            self.console_output.insert("end", f"{output}\n")
            self.console_output.insert("end", "─" * 50 + "\n\n")
        
        self.console_output.insert("end", "═══════════════════════════════════════════════\n")
        self.console_output.insert("end", "  ДИАГНОСТИКА ЗАВЕРШЕНА\n")
        self.console_output.insert("end", "═══════════════════════════════════════════════\n")
    
    def run_tests(self):
        """Run tests"""
        self.show_page("tools")
        messagebox.showinfo(
            self.t("run_tests_title"),
            self.t("run_tests_text")
        )
        
        test_script = self.appfiles_dir / "utils" / "test zapret.ps1"
        if not test_script.exists():
            test_script = self.script_dir / "utils" / "test zapret.ps1"
        if test_script.exists():
            subprocess.Popen(
                ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(test_script)],
                cwd=str(self.script_dir)
            )
        else:
            messagebox.showerror(self.t("error"), self.t("test_script_not_found"))
    
    def auto_select_strategy(self):
        """Auto-select working strategy by testing each one"""
        response = messagebox.askyesno(
            self.t("auto_select_title"),
            self.t("auto_select_text")
        )
        
        if response:
            self.show_page("tools")
            threading.Thread(
                target=self._auto_select_thread,
                daemon=True
            ).start()
    
    def _auto_select_thread(self):
        """Auto-select strategy in background thread with automatic testing"""
        try:
            import time
            import urllib.request
            import socket
            
            # Get all strategies
            strategies = self.get_available_strategies()
            if not strategies or strategies == ["No strategies found"]:
                messagebox.showerror(
                    self.t("error"),
                    self.t("no_strategies")
                )
                return
            
            # Stop any running services
            subprocess.run('sc stop zapret', shell=True, capture_output=True)
            subprocess.run('taskkill /IM winws.exe /F', shell=True, capture_output=True)
            time.sleep(2)
            
            # Test sites
            test_sites = [
                ("Discord", "https://discord.com"),
                ("YouTube", "https://www.youtube.com"),
                ("Cloudflare", "https://www.cloudflare.com")
            ]
            
            best_strategy = None
            best_score = 0
            results_log = []
            
            # Test each strategy
            for idx, strategy in enumerate(strategies, 1):
                # Update console
                self.console_output.delete("1.0", "end")
                self.console_output.insert("1.0", 
                    f"═══════════════════════════════════════════════\n"
                    f"  АВТОПОДБОР СТРАТЕГИИ ({idx}/{len(strategies)})\n"
                    f"═══════════════════════════════════════════════\n\n"
                    f"Тестирование: {strategy}\n\n"
                    f"Запуск стратегии...\n"
                )
                
                # Find strategy file
                strategy_path = None
                appfiles_strategy = self.appfiles_dir / strategy
                if appfiles_strategy.exists():
                    strategy_path = appfiles_strategy
                else:
                    root_strategy = self.script_dir / strategy
                    if root_strategy.exists():
                        strategy_path = root_strategy
                
                if not strategy_path:
                    self.console_output.insert("end", f"❌ Файл не найден\n\n")
                    continue
                
                # Start strategy
                process = None
                try:
                    # Run strategy silently
                    process = subprocess.Popen(
                        [str(strategy_path)],
                        cwd=str(strategy_path.parent),
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        creationflags=subprocess.CREATE_NO_WINDOW
                    )
                    
                    self.console_output.insert("end", f"✅ Стратегия запущена\n\n")
                    
                    # Wait for strategy to initialize
                    time.sleep(5)
                    
                    # Test each site
                    score = 0
                    test_results = []
                    
                    for site_name, site_url in test_sites:
                        self.console_output.insert("end", f"Проверка {site_name}... ")
                        self.console_output.see("end")
                        
                        try:
                            # Try to connect with timeout
                            req = urllib.request.Request(
                                site_url,
                                headers={'User-Agent': 'Mozilla/5.0'}
                            )
                            response = urllib.request.urlopen(req, timeout=10)
                            
                            if response.status == 200:
                                self.console_output.insert("end", f"✅ OK\n")
                                score += 1
                                test_results.append(f"✅ {site_name}")
                            else:
                                self.console_output.insert("end", f"⚠️ {response.status}\n")
                                test_results.append(f"⚠️ {site_name}")
                        except socket.timeout:
                            self.console_output.insert("end", f"❌ Timeout\n")
                            test_results.append(f"❌ {site_name} (timeout)")
                        except urllib.error.URLError as e:
                            self.console_output.insert("end", f"❌ Error\n")
                            test_results.append(f"❌ {site_name}")
                        except Exception as e:
                            self.console_output.insert("end", f"❌ {str(e)[:20]}\n")
                            test_results.append(f"❌ {site_name}")
                        
                        self.console_output.see("end")
                    
                    # Log results
                    result_text = f"{strategy}: {score}/{len(test_sites)} - {', '.join(test_results)}"
                    results_log.append((strategy, score, test_results))
                    
                    self.console_output.insert("end", f"\nРезультат: {score}/{len(test_sites)} тестов пройдено\n\n")
                    
                    # Update best strategy
                    if score > best_score:
                        best_score = score
                        best_strategy = strategy
                        
                        # If perfect score, we can stop early
                        if score == len(test_sites):
                            self.console_output.insert("end", f"🎉 Найдена идеальная стратегия!\n\n")
                    
                except Exception as e:
                    self.console_output.insert("end", f"\n❌ Ошибка: {str(e)}\n\n")
                    results_log.append((strategy, 0, [f"❌ Error: {str(e)[:30]}"]))
                finally:
                    # Stop strategy
                    subprocess.run('taskkill /IM winws.exe /F', shell=True, capture_output=True)
                    if process:
                        try:
                            process.terminate()
                            process.wait(timeout=3)
                        except:
                            try:
                                process.kill()
                            except:
                                pass
                    time.sleep(2)
                
                # If we found perfect strategy, ask to install
                if best_score == len(test_sites) and best_strategy == strategy:
                    results_text = "\n".join(test_results)
                    install = messagebox.askyesno(
                        self.t("auto_select_found"),
                        self.t("auto_select_found_text").format(strategy, results_text)
                    )
                    
                    if install:
                        self.strategy_var.set(strategy)
                        self._install_service_thread(strategy)
                        
                        self.console_output.delete("1.0", "end")
                        self.console_output.insert("1.0",
                            f"═══════════════════════════════════════════════\n"
                            f"  АВТОПОДБОР ЗАВЕРШЁН\n"
                            f"═══════════════════════════════════════════════\n\n"
                            f"✅ Найдена и установлена стратегия: {strategy}\n\n"
                            f"Результаты:\n{results_text}\n"
                        )
                        return
            
            # All strategies tested
            self.console_output.delete("1.0", "end")
            self.console_output.insert("1.0",
                f"═══════════════════════════════════════════════\n"
                f"  АВТОПОДБОР ЗАВЕРШЁН\n"
                f"═══════════════════════════════════════════════\n\n"
            )
            
            # Show all results
            self.console_output.insert("end", "Результаты тестирования:\n\n")
            for strategy, score, tests in results_log:
                self.console_output.insert("end", f"{strategy}: {score}/{len(test_sites)}\n")
                for test in tests:
                    self.console_output.insert("end", f"  {test}\n")
                self.console_output.insert("end", "\n")
            
            # Offer best strategy
            if best_strategy and best_score > 0:
                best_results = next((tests for s, sc, tests in results_log if s == best_strategy), [])
                results_text = "\n".join(best_results)
                
                install = messagebox.askyesno(
                    self.t("auto_select_complete"),
                    self.t("auto_select_complete_text").format(best_strategy, results_text)
                )
                
                if install:
                    self.strategy_var.set(best_strategy)
                    self._install_service_thread(best_strategy)
                    
                    self.console_output.insert("end",
                        f"\n✅ Установлена лучшая стратегия: {best_strategy}\n"
                    )
            else:
                messagebox.showwarning(
                    self.t("auto_select_no_working"),
                    self.t("auto_select_no_working_text")
                )
                
                self.console_output.insert("end",
                    f"\n❌ Рабочая стратегия не найдена.\n\n"
                    f"Рекомендации:\n"
                    f"1. Включите Secure DNS в браузере\n"
                    f"2. Перезагрузите компьютер\n"
                    f"3. Проверьте настройки антивируса\n"
                    f"4. Попробуйте вручную через вкладку Службы\n"
                )
            
        except Exception as e:
            messagebox.showerror(
                self.t("error"),
                f"Ошибка автоподбора:\n{str(e)}"
            )
            self.console_output.insert("end", f"\n\n❌ ОШИБКА: {str(e)}\n")


def main():
    """Main entry point"""
    # Check if running as admin
    try:
        import ctypes
        is_admin = ctypes.windll.shell32.IsUserAnAdmin()
    except:
        is_admin = False
    
    if not is_admin:
        response = messagebox.askyesno(
            "Administrator Rights Required",
            "FLbuster requires administrator rights to manage services.\n\n"
            "Some features may not work without admin rights.\n\n"
            "Continue anyway?"
        )
        if not response:
            sys.exit(0)
    
    app = ZapretGUI()
    app.mainloop()


if __name__ == "__main__":
    main()
