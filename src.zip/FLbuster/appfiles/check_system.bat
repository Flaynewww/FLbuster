@echo off
chcp 65001 > nul
title Zapret GUI - Проверка системы
color 0B

echo.
echo ╔═══════════════════════════════════════════════════════════════╗
echo ║              ZAPRET GUI - ПРОВЕРКА СИСТЕМЫ                    ║
echo ╚═══════════════════════════════════════════════════════════════╝
echo.

set "ERRORS=0"
set "WARNINGS=0"

:: Check Windows version
echo [1/8] Проверка версии Windows...
ver | findstr /i "Windows" > nul
if %errorLevel% neq 0 (
    echo [✗] Не удалось определить версию Windows
    set /a ERRORS+=1
) else (
    ver
    echo [✓] Windows обнаружена
)
echo.

:: Check Python
echo [2/8] Проверка Python...
where python >nul 2>&1
if %errorLevel% neq 0 (
    echo [✗] Python не найден!
    echo     Установите Python 3.8+ с https://www.python.org/
    echo     При установке отметьте "Add Python to PATH"
    set /a ERRORS+=1
) else (
    python --version
    echo [✓] Python найден
    
    :: Check Python version
    python -c "import sys; exit(0 if sys.version_info >= (3, 8) else 1)" >nul 2>&1
    if %errorLevel% neq 0 (
        echo [!] Рекомендуется Python 3.8 или новее
        set /a WARNINGS+=1
    )
)
echo.

:: Check pip
echo [3/8] Проверка pip...
python -m pip --version >nul 2>&1
if %errorLevel% neq 0 (
    echo [✗] pip не найден!
    echo     Переустановите Python с включенным pip
    set /a ERRORS+=1
) else (
    python -m pip --version
    echo [✓] pip найден
)
echo.

:: Check CustomTkinter
echo [4/8] Проверка CustomTkinter...
python -c "import customtkinter" >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] CustomTkinter не установлен
    echo     Запустите install_gui.bat для установки
    set /a WARNINGS+=1
) else (
    python -c "import customtkinter; print(f'CustomTkinter {customtkinter.__version__}')"
    echo [✓] CustomTkinter установлен
)
echo.

:: Check admin rights
echo [5/8] Проверка прав администратора...
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] Скрипт запущен БЕЗ прав администратора
    echo     Некоторые функции могут не работать
    echo     Используйте run_gui_admin.bat для запуска с правами
    set /a WARNINGS+=1
) else (
    echo [✓] Права администратора есть
)
echo.

:: Check required files
echo [6/8] Проверка файлов...
set "FILES_OK=1"

if not exist "zapret_gui.py" (
    echo [✗] zapret_gui.py не найден
    set "FILES_OK=0"
)
if not exist "requirements.txt" (
    echo [✗] requirements.txt не найден
    set "FILES_OK=0"
)
if not exist "service.bat" (
    echo [✗] service.bat не найден
    set "FILES_OK=0"
)
if not exist "bin\" (
    echo [✗] Папка bin не найдена
    set "FILES_OK=0"
)
if not exist "lists\" (
    echo [✗] Папка lists не найдена
    set "FILES_OK=0"
)

if "%FILES_OK%"=="1" (
    echo [✓] Все необходимые файлы на месте
) else (
    echo [✗] Некоторые файлы отсутствуют
    echo     Распакуйте архив полностью
    set /a ERRORS+=1
)
echo.

:: Check services
echo [7/8] Проверка служб...
sc query "zapret" >nul 2>&1
if %errorLevel%==0 (
    echo [i] Служба Zapret установлена
    sc query "zapret" | findstr "RUNNING" >nul
    if %errorLevel%==0 (
        echo [✓] Служба Zapret запущена
    ) else (
        echo [!] Служба Zapret остановлена
    )
) else (
    echo [i] Служба Zapret не установлена (это нормально для первого запуска)
)
echo.

:: Check processes
echo [8/8] Проверка процессов...
tasklist /FI "IMAGENAME eq winws.exe" | find /I "winws.exe" > nul
if %errorLevel%==0 (
    echo [✓] Процесс обхода (winws.exe) запущен
) else (
    echo [i] Процесс обхода не запущен (это нормально, если служба не установлена)
)
echo.

:: Summary
echo ═══════════════════════════════════════════════════════════════
echo.
echo РЕЗУЛЬТАТЫ ПРОВЕРКИ:
echo.

if %ERRORS%==0 (
    if %WARNINGS%==0 (
        echo [✓] Система готова к работе!
        echo     Запустите run_gui_admin.bat для начала работы
    ) else (
        echo [!] Система готова, но есть предупреждения: %WARNINGS%
        echo     Рекомендуется устранить их для лучшей работы
    )
) else (
    echo [✗] Обнаружены критические ошибки: %ERRORS%
    echo [!] Предупреждения: %WARNINGS%
    echo.
    echo Необходимо устранить ошибки перед запуском GUI
)

echo.
echo ═══════════════════════════════════════════════════════════════
echo.

:: Recommendations
if %ERRORS% gtr 0 (
    echo РЕКОМЕНДАЦИИ:
    echo.
    where python >nul 2>&1
    if %errorLevel% neq 0 (
        echo • Установите Python 3.8+ с https://www.python.org/
    )
    
    if not exist "zapret_gui.py" (
        echo • Распакуйте архив Zapret полностью
    )
    
    echo.
)

pause
