#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Utility functions for Zapret GUI
"""

import subprocess
import sys
from pathlib import Path


def check_admin():
    """Check if running with administrator privileges"""
    try:
        import ctypes
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False


def request_admin():
    """Request administrator privileges"""
    try:
        import ctypes
        if not check_admin():
            # Re-run the program with admin rights
            ctypes.windll.shell32.ShellExecuteW(
                None, "runas", sys.executable, " ".join(sys.argv), None, 1
            )
            return True
    except:
        pass
    return False


def check_python_version():
    """Check if Python version is compatible"""
    return sys.version_info >= (3, 8)


def check_dependencies():
    """Check if all required dependencies are installed"""
    try:
        import customtkinter
        return True
    except ImportError:
        return False


def install_dependencies():
    """Install required dependencies"""
    try:
        subprocess.check_call([
            sys.executable, "-m", "pip", "install", "-r", "requirements.txt"
        ])
        return True
    except:
        return False


def get_service_status(service_name):
    """Get Windows service status"""
    try:
        result = subprocess.run(
            ["sc", "query", service_name],
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='replace'
        )
        
        if "RUNNING" in result.stdout:
            return "running"
        elif "STOPPED" in result.stdout:
            return "stopped"
        elif "STOP_PENDING" in result.stdout:
            return "stopping"
        elif "START_PENDING" in result.stdout:
            return "starting"
        else:
            return "not_installed"
    except:
        return "error"


def is_process_running(process_name):
    """Check if a process is running"""
    try:
        result = subprocess.run(
            ["tasklist", "/FI", f"IMAGENAME eq {process_name}"],
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='replace'
        )
        return process_name.lower() in result.stdout.lower()
    except:
        return False


def get_zapret_version():
    """Get Zapret version from service.bat"""
    try:
        service_file = Path("service.bat")
        if service_file.exists():
            content = service_file.read_text(encoding='utf-8', errors='ignore')
            for line in content.split('\n'):
                if 'LOCAL_VERSION' in line and '=' in line:
                    version = line.split('=')[1].strip().strip('"')
                    return version
    except:
        pass
    return "Unknown"


def format_file_size(size_bytes):
    """Format file size in human readable format"""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.1f} TB"


def validate_ip(ip):
    """Validate IP address format"""
    import re
    pattern = r'^(\d{1,3}\.){3}\d{1,3}(\/\d{1,2})?$'
    if re.match(pattern, ip):
        parts = ip.split('/')[0].split('.')
        return all(0 <= int(part) <= 255 for part in parts)
    return False


def validate_domain(domain):
    """Validate domain name format"""
    import re
    pattern = r'^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$'
    return bool(re.match(pattern, domain))


if __name__ == "__main__":
    # Test utilities
    print(f"Admin: {check_admin()}")
    print(f"Python version OK: {check_python_version()}")
    print(f"Dependencies OK: {check_dependencies()}")
    print(f"Zapret version: {get_zapret_version()}")
    print(f"Zapret service: {get_service_status('zapret')}")
    print(f"WinDivert service: {get_service_status('WinDivert')}")
    print(f"winws.exe running: {is_process_running('winws.exe')}")
