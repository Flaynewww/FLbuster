#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Create a simple icon for Zapret GUI
"""

try:
    from PIL import Image, ImageDraw, ImageFont
    
    # Create icon
    size = 256
    img = Image.new('RGB', (size, size), color='#1a1a1a')
    draw = ImageDraw.Draw(img)
    
    # Draw lightning bolt (simplified)
    points = [
        (size*0.45, size*0.2),
        (size*0.55, size*0.45),
        (size*0.65, size*0.45),
        (size*0.55, size*0.8),
        (size*0.45, size*0.55),
        (size*0.35, size*0.55),
    ]
    draw.polygon(points, fill='#1f6feb', outline='#58a6ff')
    
    # Save as ICO
    img.save('zapret_icon.ico', format='ICO', sizes=[(256, 256), (128, 128), (64, 64), (32, 32), (16, 16)])
    print("Icon created successfully: zapret_icon.ico")
    
except ImportError:
    print("Pillow not installed. Icon creation skipped.")
    print("Install with: pip install Pillow")
except Exception as e:
    print(f"Error creating icon: {e}")
