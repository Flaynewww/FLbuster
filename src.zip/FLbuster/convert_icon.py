#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Convert PNG icon to ICO format for FLbuster
"""

from pathlib import Path

try:
    from PIL import Image
    
    # Paths
    png_path = Path("Icon/icon.png")
    ico_path = Path("Icon/icon.ico")
    
    if not png_path.exists():
        print(f"❌ Файл не найден: {png_path}")
        print(f"   Создайте папку Icon/ и поместите туда icon.png")
        exit(1)
    
    print(f"📂 Загрузка: {png_path}")
    
    # Load PNG
    img = Image.open(png_path)
    
    # Convert to RGBA if needed
    if img.mode != 'RGBA':
        img = img.convert('RGBA')
    
    print(f"📐 Размер: {img.size}")
    
    # Save as ICO with multiple sizes
    print(f"💾 Сохранение: {ico_path}")
    img.save(
        ico_path, 
        format='ICO', 
        sizes=[
            (256, 256),
            (128, 128),
            (64, 64),
            (48, 48),
            (32, 32),
            (16, 16)
        ]
    )
    
    print(f"✅ Иконка создана: {ico_path}")
    print(f"   Размер файла: {ico_path.stat().st_size / 1024:.1f} KB")
    
except ImportError:
    print("❌ Pillow не установлен!")
    print("   Установите: pip install Pillow")
    exit(1)
    
except Exception as e:
    print(f"❌ Ошибка: {e}")
    exit(1)
